# Lambda 0.7 parent-15 and proxy-CE supplement

Authorized by the user's 2026-09-24 request after the 2026-09-23 stop. This is a narrower new run; it does not resume the stopped three-cycle sweep or its heartbeat. Use one `zhai_p` L40S GPU at a time, account `xz2lab`, and preserve all prior outputs. No extension beyond the first 15 blocks, forks, or J analyses are newly run.

The assignment matrix in `Split (1).pdf` pp. 6–7 supplies four beta values `0.0005, 0.001, 0.0015, 0.002` and seeds `202,303,404,505,606` for lambda `0.7`. Reuse an existing complete 15-block parent only after checking its block manifests and per-step data. The first two beta groups have five such parents each; beta `0.0015` and `0.002` require new parent runs. Complete and verify each five-seed report before submitting the next beta group.

## Measurement dictionary

The old `proxy_pre/post` is the **selected hard pseudo-label CE** on the current strong-view adaptation batch; selected means the confidence mask used for training. The requested broader reported proxy O has no single explicit formula in the prior documents. Report the following separate measurements for every scheduled minibatch, before and after its update, using its saved fixed views/targets:

- Hard pseudo-label CE on all batch images, selected images, and unselected images. The all-image value is a measurement, not the training loss; the training update remains selected-only.
- Soft mixed-target cross-entropy on the same three populations, using saved detached `target_probs`. Label it as a diagnostic, not as the hard-label training objective.
- True-label CE on all batch images as an offline diagnostic. Labels never enter training or selection.
- Counts, coverage, confidence, and missing/empty-mask reasons. Aggregate by image-weighted numerators and denominators, not unweighted means of minibatch means. Keep unsmoothed step and block CSVs and plot trajectories.

For any empty population, store missing plus a reason, not zero. Verify the selected hard CE against the original `proxy_pre/post`, and verify the hashed source files used for this analysis (step archives, update logs, block summaries). Record that this is narrower than a full checkpoint-manifest audit. Report finite numerical failures honestly. Do not identify these diagnostics as a closed Jacobian, phase transition, or persistent deterioration.

Source of truth: Sapelo `/scratch/yz54720/RSI2RSD/C4/`; prior parent paths under `sweep_yingchuan_20260923/results/`; new parent paths under `parent15_o_20260924/`. Compact tables/PDF and a source index may be mirrored project-locally. The confirmation audit stays unopened. GitHub delivery, if performed, is only under `experiment/C4/C4/`, never `main`.
