"""Plot verified parent-15 CSVs with the system plotting runtime."""

import csv
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def read_csv(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def plot(blocks, columns, titles, output, beta):
    fig, axes = plt.subplots(2, 2, figsize=(11.2, 6.3), sharex=True)
    palette = dict(zip([202,303,404,505,606], plt.cm.tab10.colors[:5]))
    for ax, column, title in zip(axes.ravel(), columns, titles):
        for seed, color in palette.items():
            rows = sorted((r for r in blocks if int(r["seed"]) == seed), key=lambda r:int(r["block"]))
            ax.plot([int(r["block"]) for r in rows],
                    [float(r[column]) if r[column] else float("nan") for r in rows],
                    color=color, linewidth=1.6, marker="o", markersize=2.5, label=str(seed))
        ax.set_title(title, fontsize=10, color="#19324b")
        ax.set_xticks(range(1,16,2))
        ax.grid(alpha=.22)
        ax.set_ylabel("Cross-entropy" if "coverage" not in column else "Fraction")
    for ax in axes[1]: ax.set_xlabel("Parent block")
    axes[0,0].legend(ncol=5, fontsize=8, loc="best", frameon=False)
    fig.suptitle(f"Lambda 0.7, beta {beta}: unsmoothed five-seed block trajectories", fontsize=12)
    fig.tight_layout(rect=(0,0,1,.95))
    fig.savefig(output, dpi=180, bbox_inches="tight")
    plt.close(fig)


def main():
    blocks = read_csv(sys.argv[1])
    out = Path(sys.argv[2]); beta = sys.argv[3]
    plot(blocks,
         ["hard_all_pre","hard_all_post","hard_selected_post","hard_unselected_post"],
         ["Hard pseudo CE / all / before","Hard pseudo CE / all / after",
          "Hard pseudo CE / selected / after","Hard pseudo CE / unselected / after"],
         out/"hard_o.png", beta)
    plot(blocks,
         ["soft_all_post","true_all_post","student_audit_post_ce","coverage"],
         ["Soft mixed-target CE / all / after","True-label CE / adaptation batch / after",
          "True-label CE / held-out audit / after","Selected fraction"],
         out/"diagnostics.png", beta)


if __name__ == "__main__":
    main()
