"""Recompute several explicitly labelled proxy-CE measurements from C4 step tapes.

Run as a CPU Slurm job. This never updates the learner or uses labels for training.
"""

import argparse
import csv
import hashlib
import io
import json
import math
from collections import defaultdict
from pathlib import Path

import numpy as np


METRICS = ("hard", "soft", "true")
GROUPS = ("all", "selected", "unselected")
PHASES = ("pre", "post")


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def checked_bytes(path, expected):
    raw = path.read_bytes()
    actual = sha_bytes(raw)
    if actual != expected:
        raise ValueError(f"SHA256 mismatch: {path}")
    return raw


def cross_entropies(logits, pseudo, targets, labels):
    logits = np.asarray(logits, dtype=np.float64)
    if not np.isfinite(logits).all():
        raise ValueError("nonfinite logits")
    peak = logits.max(axis=1, keepdims=True)
    logp = logits - (peak + np.log(np.exp(logits - peak).sum(axis=1, keepdims=True)))
    pseudo = np.asarray(pseudo, dtype=np.int64)
    labels = np.asarray(labels, dtype=np.int64)
    targets = np.asarray(targets, dtype=np.float64)
    n = len(logits)
    if pseudo.shape != (n,) or labels.shape != (n,) or targets.shape != logits.shape:
        raise ValueError("step archive shape mismatch")
    if not np.isfinite(targets).all() or np.max(np.abs(targets.sum(axis=1) - 1)) > 1e-4:
        raise ValueError("invalid soft targets")
    ix = np.arange(n)
    return {
        "hard": -logp[ix, pseudo],
        "soft": -(targets * logp).sum(axis=1),
        "true": -logp[ix, labels],
    }


def add_metrics(row, buckets, arrays, phase, mask):
    groups = {"all": np.ones(len(mask), dtype=bool), "selected": mask, "unselected": ~mask}
    for metric, values in arrays.items():
        for group, subset in groups.items():
            name = f"{metric}_{group}_{phase}"
            count = int(subset.sum())
            row[name] = float(values[subset].mean()) if count else None
            if count:
                buckets[name][0] += float(values[subset].sum())
                buckets[name][1] += count


def means(buckets):
    return {name: (numer / count if count else None) for name, (numer, count) in buckets.items()}


def count_buckets():
    return defaultdict(lambda: [0.0, 0])


def audit_parent(seed, parent, pair, beta):
    markers = sorted(parent.glob("block_*/attempt_*/complete.json"))
    if len(markers) != 15:
        raise ValueError(f"{seed}: expected 15 completed parent blocks; found {len(markers)}")
    if [int(p.parents[1].name.split("_")[1]) for p in markers] != list(range(15)):
        raise ValueError(f"{seed}: block indices are incomplete or repeated")
    status = json.loads((parent / "status.json").read_text())
    if status.get("status") != "complete" or status.get("completed_blocks") != 15:
        raise ValueError(f"{seed}: parent status is not complete 15/15")
    steps, blocks = [], []
    cell_buckets = count_buckets()
    for marker in markers:
        marker_data = json.loads(marker.read_text())
        files = marker_data["files"]
        base = marker.parent
        block = int(marker_data["block"])
        summary = json.loads(checked_bytes(base / "summary.json", files["summary.json"]))
        records = [json.loads(line) for line in checked_bytes(
            base / "updates.jsonl", files["updates.jsonl"]).decode().splitlines()]
        if len(records) != summary["batches"]:
            raise ValueError(f"{seed} block {block}: batch count mismatch")
        block_buckets = count_buckets()
        n_total = n_selected = 0
        for record in records:
            batch = int(record["batch"])
            filename = f"batch_{batch:03d}.npz"
            raw = checked_bytes(base / filename, files[filename])
            with np.load(io.BytesIO(raw), allow_pickle=False) as tape:
                mask = np.asarray(tape["mask"], dtype=bool)
                pseudo = tape["pseudo"]
                labels = tape["labels"]
                targets = tape["target_probs"]
                pre = cross_entropies(tape["student_before"], pseudo, targets, labels)
                post = cross_entropies(tape["student_after"], pseudo, targets, labels)
            n = len(mask)
            selected = int(mask.sum())
            if n != record["n"] or selected != record["selected"]:
                raise ValueError(f"{seed} block {block} batch {batch}: count mismatch")
            row = {"pair": pair, "lambda": 0.7, "beta": beta, "seed": seed,
                   "block": block + 1, "domain": record["domain"], "batch": batch,
                   "images": n, "selected": selected, "unselected": n-selected,
                   "coverage": selected/n, "updated": record["updated"],
                   "confidence_mean": record["confidence_mean"],
                   "original_selected_proxy_pre": record["proxy_pre"],
                   "original_selected_proxy_post": record["proxy_post"]}
            for phase, values in (("pre", pre), ("post", post)):
                add_metrics(row, block_buckets, values, phase, mask)
                add_metrics({}, cell_buckets, values, phase, mask)
            for phase in PHASES:
                got = row[f"hard_selected_{phase}"]
                original = record[f"proxy_{phase}"]
                if (got is None) != (original is None) or (got is not None and abs(got-original) > 1e-4):
                    raise ValueError(f"{seed} block {block} batch {batch}: selected CE mismatch")
            steps.append(row)
            n_total += n
            n_selected += selected
        if n_total != summary["images"] or n_selected != summary["selected"]:
            raise ValueError(f"{seed} block {block}: summary count mismatch")
        blocks.append({"pair": pair, "lambda": 0.7, "beta": beta, "seed": seed,
                       "block": block + 1, "domain": summary["domain"],
                       "images": n_total, "selected": n_selected, "coverage": n_selected/n_total,
                       "student_audit_pre_ce": summary["pre"]["student"]["ce"],
                       "student_audit_post_ce": summary["post"]["student"]["ce"],
                       "teacher_audit_pre_ce": summary["pre"]["teacher"]["ce"],
                       "teacher_audit_post_ce": summary["post"]["teacher"]["ce"],
                       **means(block_buckets)})
    return steps, blocks, {"pair": pair, "lambda": 0.7, "beta": beta, "seed": seed,
                           "parent": str(parent), "blocks": 15, "steps": len(steps),
                           "images": sum(x["images"] for x in blocks),
                           "selected": sum(x["selected"] for x in blocks),
                           **means(cell_buckets)}


def write_csv(path, rows):
    if not rows:
        raise ValueError(f"no rows for {path}")
    fields = list(rows[0])
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    manifest = json.loads(args.manifest.read_text())
    pair, beta = manifest["pair"], float(manifest["beta"])
    if manifest["lambda"] != "0.7" or sorted(int(k) for k in manifest["parents"]) != [202,303,404,505,606]:
        raise ValueError("unexpected pair manifest")
    all_steps, all_blocks, cells = [], [], []
    for seed_string, parent_string in sorted(manifest["parents"].items(), key=lambda kv:int(kv[0])):
        steps, blocks, cell = audit_parent(int(seed_string), Path(parent_string), pair, beta)
        all_steps.extend(steps); all_blocks.extend(blocks); cells.append(cell)
        print(seed_string, "verified", len(steps), "steps", flush=True)
    args.out.mkdir(parents=True, exist_ok=False)
    write_csv(args.out / "O_steps.csv", all_steps)
    write_csv(args.out / "O_blocks.csv", all_blocks)
    write_csv(args.out / "O_cells.csv", cells)
    (args.out / "source_manifest.json").write_text(json.dumps(manifest, indent=2))
    for filename in ("O_steps.csv", "O_blocks.csv", "O_cells.csv", "source_manifest.json"):
        p = args.out / filename
        print(filename, p.stat().st_size, hashlib.sha256(p.read_bytes()).hexdigest(), flush=True)


if __name__ == "__main__":
    main()
