"""Build a compact, source-linked English PDF for a verified parent-15 O pair."""

import argparse
import csv
import hashlib
import json
import statistics
import subprocess
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.utils import ImageReader
from reportlab.pdfgen import canvas


NAVY = colors.HexColor("#19324b")
TEAL = colors.HexColor("#167c80")
PALE = colors.HexColor("#eaf2f3")
GREY = colors.HexColor("#576775")
W, H = landscape(A4)


def read_csv(path):
    with path.open(newline="") as f:
        return list(csv.DictReader(f))


def num(value):
    return None if value in (None, "") else float(value)


def fmt(value, digits=3):
    v = num(value)
    return "NA" if v is None else f"{v:.{digits}f}"


def lines(c, content, x, y, width, font="Helvetica", size=9, leading=12, color=GREY):
    c.setFont(font, size)
    c.setFillColor(color)
    words = content.split()
    line = ""
    for word in words:
        test = (line + " " + word).strip()
        if c.stringWidth(test, font, size) <= width:
            line = test
        else:
            c.drawString(x, y, line)
            y -= leading
            line = word
    if line:
        c.drawString(x, y, line)
        y -= leading
    return y


def page(c, section, number, beta):
    c.setFillColor(NAVY)
    c.rect(0, H-50, W, 50, fill=1, stroke=0)
    c.setFillColor(colors.white)
    c.setFont("Helvetica-Bold", 17)
    c.drawString(35, H-32, "C4 / Lambda 0.7 / Parent-15 proxy CE")
    c.setFont("Helvetica", 9)
    c.drawRightString(W-35, H-30, f"beta = {beta} | {section}")
    c.setStrokeColor(colors.HexColor("#d6e1e6"))
    c.line(35, 31, W-35, 31)
    c.setFont("Helvetica", 8)
    c.setFillColor(GREY)
    c.drawString(35, 19, "Exploratory five-seed supplement | 15 parent blocks | no extension")
    c.drawRightString(W-35, 19, f"{number} / 4")


def table(c, headers, rows, widths, x, top, row_h=25):
    total = sum(widths)
    c.setFillColor(NAVY)
    c.rect(x, top-row_h, total, row_h, fill=1, stroke=0)
    c.setFillColor(colors.white)
    c.setFont("Helvetica-Bold", 8)
    at = x
    for header, width in zip(headers, widths):
        c.drawString(at+6, top-row_h+8, header)
        at += width
    y = top-row_h
    for i, row in enumerate(rows):
        c.setFillColor(PALE if i%2==0 else colors.white)
        c.rect(x, y-row_h, total, row_h, fill=1, stroke=0)
        c.setFillColor(NAVY)
        c.setFont("Helvetica", 8)
        at = x
        for value, width in zip(row, widths):
            c.drawString(at+6, y-row_h+8, str(value)[:32])
            at += width
        y -= row_h
    return y


def build(data_dir, out_dir):
    steps = read_csv(data_dir/"O_steps.csv")
    blocks = read_csv(data_dir/"O_blocks.csv")
    cells = read_csv(data_dir/"O_cells.csv")
    manifest = json.loads((data_dir/"source_manifest.json").read_text())
    pair = manifest["pair"]
    beta = manifest["beta"]
    assert len(cells)==5 and len(blocks)==75 and len(steps)>0
    out_dir.mkdir(parents=True, exist_ok=True)
    p1 = out_dir/"hard_o.png"
    p2 = out_dir/"diagnostics.png"
    subprocess.run(["/usr/bin/python3", str(Path(__file__).with_name("plot_parent_report.py")),
                    str(data_dir/"O_blocks.csv"), str(out_dir), beta], check=True)
    pdf = out_dir/f"C4_Parent15_O_l07_b{beta.replace('.','')}_EN.pdf"
    c = canvas.Canvas(str(pdf), pagesize=(W,H))
    c.setTitle(f"C4 parent-15 full proxy CE: lambda 0.7 beta {beta}")

    page(c,"Scope and definitions",1,beta)
    c.setFillColor(NAVY);c.setFont("Helvetica-Bold",14);c.drawString(35,H-75,"Five-seed status and observable definitions")
    y=H-96
    y=lines(c,"All five seeds have 15 committed parent blocks. Previously completed parents are reused when available; no new extension, fork, or Jacobian run contributes to this supplement.",35,y,W-70,size=9,color=NAVY)
    rows=[]
    for r in cells:
        s=int(r["seed"])
        rows.append((s,"15 / 15",int(r["steps"]),f"{100*int(r['selected'])/int(r['images']):.1f}%",
                     fmt(r["hard_all_pre"]),fmt(r["hard_all_post"]),fmt(r["hard_selected_post"]),fmt(r["hard_unselected_post"])))
    y=table(c,["Seed","Blocks","Steps","Coverage","O all pre","O all post","O sel post","O unsel post"],rows,
            [56,69,64,78,96,96,105,118],35,y-9)
    y-=25
    for title,body in [
        ("O hard / all", "Mean CE against the saved hard pseudo-label for every image in each adaptation batch, before or after its update. This is a reported measurement; only selected images enter training."),
        ("O hard / selected", "The historical reported proxy CE and actual hard-label training loss, on the fixed selected mask. Recomputed values match the archived per-update logs."),
        ("O hard / unselected", "Same hard pseudo-label CE on images excluded by the confidence threshold. The selection mask and targets remain fixed across the pre/post comparison."),
        ("Additional diagnostics", "Soft mixed-target cross-entropy and offline true-label CE are also reported for all, selected and unselected images in the companion step/block CSVs. They are not interchangeable with the hard-label training objective."),
    ]:
        c.setFillColor(TEAL);c.setFont("Helvetica-Bold",9);c.drawString(35,y,title)
        y=lines(c,body,176,y, W-211, size=8,leading=11)-10
    c.showPage()

    page(c,"Complete hard-proxy curves",2,beta)
    c.drawImage(ImageReader(str(p1)),38,65,width=W-76,height=H-135,preserveAspectRatio=True,anchor="c")
    c.showPage()

    page(c,"Complementary diagnostics",3,beta)
    c.drawImage(ImageReader(str(p2)),38,65,width=W-76,height=H-135,preserveAspectRatio=True,anchor="c")
    c.showPage()

    page(c,"Interpretation and provenance",4,beta)
    c.setFillColor(NAVY);c.setFont("Helvetica-Bold",14);c.drawString(35,H-75,"What the observed CE does and does not say")
    y=H-99
    deltas=[num(r["hard_all_post"])-num(r["hard_all_pre"]) for r in cells]
    y=lines(c,f"Across five seeds, the image-weighted within-step hard all-image CE change is negative in {sum(x<0 for x in deltas)}/5 cells; the mean of five cell changes is {statistics.mean(deltas):+.4f}. These are same-batch pre/post differences, not a same-domain return trend.",35,y,W-70,size=10,color=NAVY)-16
    y=lines(c,"The selected-only objective, all-image hard pseudo-label CE, soft-target CE, true-label adaptation-batch CE, and held-out audit CE answer different questions. All are retained side by side. Labels were used only after each training decision for measurement.",35,y,W-70,size=9)-16
    y=lines(c,"This is a one-cycle 15-block readout. It cannot establish three-cycle deterioration, long-horizon feedback effects, a closed Jacobian or a phase boundary. The five seeds share the same benchmark and are exploratory, not an untouched confirmation set.",35,y,W-70,size=9)-22
    c.setFillColor(TEAL);c.setFont("Helvetica-Bold",10);c.drawString(35,y,"Complete companion evidence")
    y-=20
    for text in [
        "O_steps.csv: every minibatch, with hard/soft/true CE before and after on all, selected and unselected images.",
        "O_blocks.csv: 15 unsmoothed domain-block summaries per seed, with image-weighted CE and held-out audit CE.",
        "O_cells.csv: five full one-cycle summaries. source_manifest.json: exact Sapelo parent paths and provenance.",
        "The raw per-batch archives and checkpoints remain on Sapelo. Empty populations are NA, never zero.",
    ]:
        y=lines(c,text,35,y,W-70,size=9)-8
    y-=12
    y=lines(c,f"Source root: /scratch/yz54720/RSI2RSD/C4/ ; pair {pair}; beta {beta}. The analysis verifies SHA256 for each consumed step archive, update log and block summary and reconciles selected CE with original logs. Full checkpoint-manifest coverage is a separate audit.",35,y,W-70,size=8)-10
    c.save()

    md=out_dir/"RESULTS.md"
    md.write_text(f"# C4 parent-15 proxy CE: lambda=0.7, beta={beta}\n\n"
                  f"Purpose: collaborator report for the one-cycle parent and comprehensive proxy-CE observables. Export target: landscape-A4 PDF.\n\n"
                  f"Source: `{data_dir/'source_manifest.json'}` and the Sapelo parent paths it lists. All five seeds have 15 verified parent blocks.\n\n"
                  f"Hard all-image proxy CE is computed on every adaptation-batch image against the fixed saved pseudo-label, before and after the same update. The historical selected-only CE is reported separately and verified against source logs. Soft-target and offline true-label CE are additional diagnostics, not substitutes for the training objective.\n\n"
                  f"Step, block and cell records: `O_steps.csv`, `O_blocks.csv`, `O_cells.csv`. No extension, new fork or J measurement is included. This finite exploratory parent cannot establish sustained deterioration or a phase boundary.\n")
    verification={"pair":pair,"beta":beta,"seeds":[int(r["seed"]) for r in cells],
                  "blocks":len(blocks),"steps":len(steps),
                  "files":{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [pdf,md,p1,p2]}}
    (out_dir/"REPORT_VERIFICATION.json").write_text(json.dumps(verification,indent=2)+"\n")
    print(pdf)


if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("data_dir",type=Path);p.add_argument("out_dir",type=Path)
    a=p.parse_args();build(a.data_dir,a.out_dir)
