# C4 meeting pilot: current observations

Exploration only. One seed; no causal feedback or phase-transition conclusion.
Partial arms can cover different domains: compare matched completed blocks only.

| Arm | Blocks | Mean post error | Same-domain return change | Selection coverage | Updates |
|---|---:|---:|---:|---:|---:|
| gamma0 | 30/30 | 0.5244 | -0.0212 | 0.4309 | 2820 |
| gamma1 | 30/30 | 0.5192 | -0.0497 | 0.4331 | 2820 |

Positive return change means higher error; first-versus-last post-block visits.
Full raw logs, predictions and checkpoints remain in the corresponding run directories.

![C4-1_local.png](C4-1_local.png)

![C4-2_trajectories.png](C4-2_trajectories.png)

![C4-2b_fixed_reference.png](C4-2b_fixed_reference.png)

![C4-3_returns.png](C4-3_returns.png)

![C4-4_sweep.png](C4-4_sweep.png)
