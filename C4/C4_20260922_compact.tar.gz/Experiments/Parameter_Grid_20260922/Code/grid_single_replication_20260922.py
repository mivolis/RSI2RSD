"""C4 row-four replication: frozen code, three new seeds, two fixed parents."""
import concurrent.futures, hashlib, json, os, queue, shutil, subprocess, sys, time
from pathlib import Path
ROOT=Path('/scratch/yz54720/RSI2RSD/C4')
os.chdir(ROOT)
JOB=os.environ['SLURM_JOB_ID']
TASK=int(os.environ['SLURM_ARRAY_TASK_ID'])
POINTS=[(1.,.01),(.5,.001),(.5,.01),(0.,.001),(0.,.01)]
POINT=TASK//2 if TASK<10 else TASK-10
SEED=[202,303][TASK%2] if TASK<10 else 404
LAMBDA,BETA=POINTS[POINT]
OUT=ROOT/'grid_single_replication_20260922'/('array'+os.environ['SLURM_ARRAY_JOB_ID'])/('point'+str(POINT)+'_seed'+str(SEED)+'_job'+JOB)
OUT.mkdir(parents=True,exist_ok=False)
GPUS=os.environ['CUDA_VISIBLE_DEVICES'].split(',')
assert len(GPUS)==1
SEEDS=[SEED]
EXPECTED={'c4.py':'b98eb393f9dcf33620ef533c0bc2d9f3d74f139f19b91657297ef78688f5fc0a','forks.py':'0b4acb2302b000137df50a12dab96d9b73e8ab3050e48b78e0960390f04e33e1','verify_forks.py':'f3a243b629fcc4ad6c15206ae552cc2288e006b5f5784bc4d803c2ee64c37f7f'}
def write(p,obj):
 tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(obj,indent=2));tmp.replace(p)
def hashes():
 got={f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in EXPECTED}
 assert got==EXPECTED,got
 return got
started=time.time()
write(OUT/'contract.json',dict(seeds=SEEDS,parents=[5,15],horizons=[94,1410],gamma=LAMBDA,beta=BETA,point_index=POINT,task_index=TASK,array_job=os.environ['SLURM_ARRAY_JOB_ID'],parent_cycles=1,job=JOB,code_sha256=hashes(),scope='exploratory independent training seeds; unchanged exploratory panel; confirmation untouched',selection='first nonempty proposal after each fixed parent; no sign-based selection',started_unix=started))
(OUT/'code').mkdir()
for f in list(EXPECTED)+['run_measured_fork.py','test_c4.py','test_forks.py']:
 shutil.copy2(ROOT/f,OUT/'code'/f)
shutil.copy2(__file__,OUT/'code'/Path(__file__).name)
shutil.copy2(ROOT/'slurm/grid_single_replication_20260922.sbatch',OUT/'code/grid_single_replication_20260922.sbatch')
slots=queue.Queue()
for gpu in GPUS:slots.put(gpu)
def run_task(task):
 name,cmd=task;gpu=slots.get();begin=time.time()
 env=os.environ.copy();env['CUDA_VISIBLE_DEVICES']=gpu
 write(OUT/(name+'_execution.json'),dict(status='running',command=cmd,gpu=gpu,started_unix=begin))
 try:
  hashes()
  with (OUT/(name+'.log')).open('w') as log:
   subprocess.run([sys.executable,'-u']+cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
  write(OUT/(name+'_execution.json'),dict(status='complete',command=cmd,gpu=gpu,started_unix=begin,elapsed_seconds=time.time()-begin))
 finally:slots.put(gpu)
def phase(name,tasks):
 write(OUT/'status.json',dict(status='running',phase=name,job=JOB,elapsed_seconds=time.time()-started))
 with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
  list(pool.map(run_task,tasks))
try:
 for test in ['test_c4.py','test_forks.py']:
  with (OUT/(test+'.log')).open('w') as log:subprocess.run([sys.executable,test],stdout=log,stderr=subprocess.STDOUT,check=True)
 phase('parents',[(f'parent_seed{s}',['c4.py','--data','data/CIFAR-100-C','--output',str(OUT/f'parent_seed{s}'),'--gamma',str(LAMBDA),'--beta',str(BETA),'--seed',str(s),'--cycles','1']) for s in SEEDS])
 for s in SEEDS:
  parent=OUT/f'parent_seed{s}'
  assert json.loads((parent/'status.json').read_text())['status']=='complete'
  markers=list(parent.glob('block_*/attempt_*/complete.json'));assert len(markers)==15
  checked=0
  for marker in markers:
   for file,digest in json.loads(marker.read_text())['files'].items():
    assert hashlib.sha256((marker.parent/file).read_bytes()).hexdigest()==digest
    checked+=1
  write(parent/'replication_verification.json',dict(status='verified',blocks=15,hashed_files=checked))
 for horizon in [94,1410]:
  tasks=[]
  for s in SEEDS:
   for b in [5,15]:
    dest=OUT/f'seed{s}_after{b}_h{horizon}'
    tasks.append((dest.name,['run_measured_fork.py',str(dest),'--parent',str(OUT/f'parent_seed{s}'),'--data','data/CIFAR-100-C','--after-block',str(b),'--horizon',str(horizon),'--output',str(dest)]))
  phase('forks_h'+str(horizon),tasks)
  phase('verification_h'+str(horizon),[(f'verify_seed{s}_after{b}_h{horizon}',['verify_forks.py',str(OUT/f'seed{s}_after{b}_h{horizon}')]) for s in SEEDS for b in [5,15]])
  write(OUT/f'h{horizon}_verified.json',dict(status='verified',seeds=SEEDS,parents=[5,15]))
 if LAMBDA==0:
  for seed in SEEDS:
   for block in [5,15]:
    for horizon in [94,1410]:
     rows=json.loads((OUT/f'seed{seed}_after{block}_h{horizon}/comparison.json').read_text())
     assert all(abs(row['I_feedback'])<=1e-7 for row in rows), 'lambda0 feedback negative control failed'
  write(OUT/'lambda0_control.json',dict(status='verified',claim='closed/replay CE contrasts zero at all recorded audit points'))
 hashes()
 write(OUT/'status.json',dict(status='complete',job=JOB,elapsed_seconds=time.time()-started))
except BaseException as exc:
 write(OUT/'status.json',dict(status='failed',job=JOB,error=repr(exc),elapsed_seconds=time.time()-started))
 raise
