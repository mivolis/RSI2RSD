# C4 five-point exploratory parameter grid — 2026-09-22

## Authorized scope and scheduling
User authorized five new (lambda,beta) points: (1,.01), (.5,.001), (.5,.01), (0,.001), (0,.01), each seeds 202/303/404. Existing (1,.001) baseline is reused. Latest authorization: at most THREE GPUs on zhai_p. All seeds202/303 run before any404.

- First array: 48445435, indices0–9, throttle3 (updated from2 after submission).
- Second array: 48445442, indices10–14, throttle3, dependency afterany:48445435 (updated after observed numerical failures;404 still waits for all first-stage tasks to terminate).
- Task mapping: t<10 => point=t//2, seed=[202,303][t%2]; otherwise point=t-10, seed404.
- Account xz2lab, partition zhai_p, generic gpu:1 per task;4CPUs/16GB/90min each. Public dry runs hit QOSMaxSubmitJobPerUserLimit; zhai prediction15:13. Two tasks observed running on rb7-1 after submission. First10 estimated ~3hours on3GPUs, subject to availability and observed timings; not a guarantee.
- Operator codex-sapelo; transfer yz54720@xfer.gacrc.uga.edu.
- Remote root /scratch/yz54720/RSI2RSD/C4.
- Entry scripts slurm/grid_single_replication_20260922.py and .sbatch. Local Code snapshots retained. Sbatch default array directive is overridden by submission arguments above.
- Outputs grid_single_replication_20260922/array{ARRAY_JOB_ID}/point{POINT}_seed{SEED}_job{SLURM_JOB_ID}/; logs logs/grid-{ARRAY_JOB_ID}_{TASK_ID}.{out,err}.

## Scientific contract
Unchanged learner and forks. One-cycle parent for each cell; fixed block5/15 parents, first nonempty proposal without sign selection. H94/H1410, reject_closed/accept_closed/accept_replay. Source checkpoint and data unchanged; confirmation panel untouched. Seeds303/404 already exploratory. Preserve all intermediate raw records and failed attempts. No paid compute or extra points.

Core SHA256: c4.py b98eb393f9dcf33620ef533c0bc2d9f3d74f139f19b91657297ef78688f5fc0a; forks.py 0b4acb2302b000137df50a12dab96d9b73e8ab3050e48b78e0960390f04e33e1; verify_forks.py f3a243b629fcc4ad6c15206ae552cc2288e006b5f5784bc4d803c2ee64c37f7f.

## Acceptance and delivery
Require all15parents and60forks complete and hash-verified, software checks passed, sacct COMPLETED0:0. Verify shared H94/H1410 raw prefixes. At lambda0, closed/replay interaction must be zero within numerical tolerance; compare student dynamics across beta (not independent evidence). Preserve CE/error full audit curves, immediate effects, H94/1409/1410 A_closed/A_open/I_feedback. Report each cell and paired-seed baseline comparisons with all signs, no persistent deterioration or phase-transition inference from endpoint signs.

Deliver staged English RESULTS, tables, curves and PDF after first10, then full15. Keep bulk raw evidence on Sapelo, recover compact evidence with exact indices. GitHub only mivolis/RSI2RSD branch experiment/C4 under C4/. Prior seed replication GitHub delivery remains pending; do not reupload original pilot releases.

## Early observations
First point lambda1/beta.01 seeds202/303 exited1 with nonfinite post-update loss in parent learning. Preserve failed outputs; no parameter changes or automatic rerun. Remaining cells continue. Numerical failure is not evidence of finite recursive deterioration. Final acceptance includes explicitly accounted failed cells rather than claiming all15 succeeded.

### Status at 2026-09-22 14:05 EDT
Tasks0/1/4/5 failed exit1: both seeds202/303 at lambda1/beta.01 and lambda.5/beta.01 have nonfinite post-update loss. Tasks2/3/6 are running H1410 forks (earlier phases passed);7–9 pending. All404 tasks await afterany:48445435, verified in scontrol. No reruns or parameter edits.
