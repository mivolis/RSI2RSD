# C4 row-four independent-seed replication — 2026-09-22

## Authorization and question
User requested running row four of Table 2 on page 7 of `/Users/zyc/Downloads/C4_pre.pdf` with additional seeds. Row: **Accept/reject and closed/replay forks**. This batch asks whether the immediate-to-descendant effect reversal and supervision-feedback interaction reproduce across independent training seeds. It does not authorize a parameter search or selecting favorable fork nodes.

## Frozen design
- Seeds 202, 303, 404; prior seed 101 remains a separate discovery run. Three seeds are independent training randomizations conditional on the same benchmark/data split, not independent datasets.
- These are exploratory repetitions on the original exploratory panel. Seeds 303/404 are now consumed for this purpose and must not subsequently be presented as new untouched confirmation runs. Confirmation audit images remain uninspected.
- Lambda 1, beta .001; original model, optimizer, thresholds, augmentation, split and corruption order unchanged.
- Regenerate each parent from source initialization for one full cycle (15 blocks). This supplies block-5 and block-15 checkpoints without unnecessary second-cycle parent training. The original implementation and all prefix dynamics are unchanged.
- Fork at the first nonempty next-domain update after each prescribed parent, regardless of immediate effect sign. Preserve null, beneficial and adverse outcomes.
- Run horizons 94 and 1410 for both parents, using unchanged fork code; the shorter run provides an exact H94 audit absent from the long run's audit grid. Prefixes are shared and are not independent repetitions.
- Three continuations per fork: reject_closed, accept_closed, accept_replay. Verify reject/replay identity over 20 steps, raw supervision tape identity, matched inputs and reconstructed metrics.
- Primary reporting: per-seed immediate CE effect, A_closed, A_open, I_feedback at H94, H1409, H1410, full recorded CE/error curves. Report unfiltered sign counts and descriptive between-seed variation. No phase-transition, persistent-deterioration or population-validity claim.
- Preserve checkpoints, all raw batch supervision/predictions, audit logits, schedules, hashes, logs and failures on Sapelo. Download compact verified evidence for the report; bulk outputs remain on Sapelo unless further delivery requires archiving.

## Implementation and resources
- code_id: `rsd_c4.seed_replication_20260922`
- Remote root: `/scratch/yz54720/RSI2RSD/C4`
- Added entry point: `slurm/seed_replication_20260922.py`
- Added Slurm script: `slurm/seed_replication_20260922.sbatch`
- Frozen core SHA256: c4.py `b98eb393f9dcf33620ef533c0bc2d9f3d74f139f19b91657297ef78688f5fc0a`; forks.py `0b4acb2302b000137df50a12dab96d9b73e8ab3050e48b78e0960390f04e33e1`; verify_forks.py `f3a243b629fcc4ad6c15206ae552cc2288e006b5f5784bc4d803c2ee64c37f7f`.
- No Git worktree exists at remote runtime root; hashes and saved code snapshots provide runtime provenance. GitHub delivery remains strictly `experiment/C4`, under `C4/`.
- Selected: zhai_p / xz2lab, generic gpu:2 (node supplies L40S), 8 CPUs, 32 GB RAM, 90-minute walltime. Existing unrelated jobs untouched.
- Preflight at approximately 10:11 EDT: zhai_p predicted immediate start on rb7-1, three GPUs unallocated; gpu_p/pmlab with normal or iob_p_qos predicted next-day start. iob_p has no GPUs. Comparable L40S H1410 forks took 15.4–15.9 minutes each; six forks in three two-GPU waves plus parents, short forks and verification estimated 55–75 minutes, excluding changed queue/I/O conditions.

## Execution
- Job **48431715**, verified RUNNING on rb7-1 at 2026-09-22 10:13 EDT.
- Output: `/scratch/yz54720/RSI2RSD/C4/seed_replication_20260922/job48431715/`.
- Logs: `/scratch/yz54720/RSI2RSD/C4/logs/replication-48431715.{out,err}` and per-task logs in the output directory.
- Core code snapshots and contract saved by the supervisor under the output root.
- No scientific result accepted yet.

- Existing thread heartbeat `c4-github` repurposed to this authorized batch, active every 10 minutes for bounded monitoring/verification/delivery; stop when complete. No duplicate GPU submissions.

## Access interruption — 10:52 EDT
Operator SSH timed out; Cisco explicitly reports Disconnected. UI recovery was blocked because Mac is locked; user asked to unlock. Transfer host remains reachable and authenticated rsync succeeded. Status-only preview is in `Working/status_snapshot/` (same relative paths as remote job root; disposable, not scientific evidence). Seed202 long forks completed in 984–987 seconds; seed303 long forks running. Final verification runs after all long forks. Continue file-based monitoring through xfer without submitting jobs there. Restore Operator for final sacct and browser for GitHub delivery when unlocked.
