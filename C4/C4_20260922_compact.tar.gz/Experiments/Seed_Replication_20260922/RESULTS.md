# C4 independent-seed fork replication — 2026-09-22

The original harmful long-endpoint pattern did **not** replicate consistently. At the block-5 parent, all three new candidate updates improve fixed-panel CE immediately, but only seed 202 becomes harmful relative to rejection at H1410. Seeds 303 and 404 remain beneficial, and their closed/replay interactions favor closed supervision. At block 15, all three closed acceptance effects are beneficial at H1410; the interaction is positive only for seed 202.

This is evidence of seed- and horizon-dependent effects, not a stable harmful-feedback law or persistent recursive deterioration. The new runs do not invalidate the observed discovery trajectory, but weaken its interpretation as a reproducible typical outcome.

## Execution and evidence boundary

Sapelo job 48431715 is `COMPLETED 0:0` in final Slurm accounting (elapsed 01:09:34; [scheduler record](Evidence/SCHEDULER_VERIFICATION.json)). All three parent trajectories and all 12 fork runs passed the retained independent verification records. Full remote verification covers 28,176 fork manifest members and 27,072 future raw records, plus 4,545 parent manifest members. Local transferred manifest members and all six short/long raw prefixes were checked. The earlier PDF was exported before Operator access returned and retains its dated pending-accounting caveat.

Three **new exploratory training seeds**: 202, 303, 404. Lambda 1, beta .001, fixed pretrained source, original split and exploratory panel; confirmation audit untouched. Parent trajectories are regenerated from source initialization through 15 blocks. The first nonempty proposal after block 5/15 is used regardless of sign. No algorithm changes, seed filtering, parameter search or smoothed-trend selection occurred. H94 and H1410 share prefixes; they are not independent repetitions. The two parents within one seed are correlated. Seeds 303/404 must not later be described as fresh confirmation runs.

Core training/fork code is unchanged from the discovery run. The fixed panel contains 100 base images across 15 corruptions (1,500 image-corruption pairs), not 1,500 independent base images. Three seeds do not establish a population effect or precise failure frequency.

## Comparisons

All CE differences use the same panel; positive means worse.

- `A_closed = accept_closed - reject_closed`: total effect of accepting the focal update under endogenous supervision.
- `A_open = accept_replay - reject_replay`: acceptance effect under the rejection-generated supervision tape.
- `I_feedback = A_closed - A_open`: interaction with this specific intervention. Reject/replay reproduces the donor reject path; identity is explicitly checked over 20 steps.

Replay fixes pseudo-labels and confidence masks jointly. It is not a frozen teacher, an oracle target sequence, or a separation of label and mask mechanisms. Positive interaction alone does not imply accepting is worse than rejecting.

## Primary H1410 results

| Seed | Parent | Immediate A_closed | H1410 A_closed | H1410 A_open | H1410 I_feedback |
| --- | --- | --- | --- | --- | --- |
| 202 | 5 | -0.023718 | +0.032989 | -0.032782 | +0.065771 |
| 202 | 15 | +0.028891 | -0.170110 | -0.473994 | +0.303884 |
| 303 | 5 | -0.110564 | -0.388085 | -0.022906 | -0.365179 |
| 303 | 15 | -0.176734 | -0.091562 | +0.088887 | -0.180449 |
| 404 | 5 | -0.020951 | -0.320473 | -0.184236 | -0.136237 |
| 404 | 15 | -0.019730 | -0.239155 | -0.006688 | -0.232467 |

- Block 5: 3/3 immediate CE improvements; 1/3 harmful closed acceptance endpoints; 1/3 positive feedback interactions. Seed 202 reproduces the discovery sign pattern at H1410.
- Block 15: 2/3 immediate CE improvements (seed 202 is immediately harmful); 0/3 harmful closed acceptance endpoints; 1/3 positive interactions. Seed 202 has positive interaction while acceptance is nevertheless beneficial relative to rejection.
- These counts summarize three runs per parent; they are not estimated universal probabilities. Do not combine both parents into six independent seeds.

![H1410 replication](endpoint_replication.png)

## Descriptive variation across the three new seeds

| Parent | Horizon | Contrast | Mean | Sample SD | Positive / 3 |
| --- | --- | --- | --- | --- | --- |
| 5 | 94 | A_closed | -0.078071 | 0.148668 | 1 |
| 5 | 94 | A_open | +0.034421 | 0.123712 | 2 |
| 5 | 94 | I_feedback | -0.112492 | 0.037536 | 0 |
| 5 | 1409 | A_closed | -0.204928 | 0.225313 | 1 |
| 5 | 1409 | A_open | -0.028709 | 0.062211 | 2 |
| 5 | 1409 | I_feedback | -0.176220 | 0.205320 | 1 |
| 5 | 1410 | A_closed | -0.225190 | 0.226131 | 1 |
| 5 | 1410 | A_open | -0.079975 | 0.090428 | 0 |
| 5 | 1410 | I_feedback | -0.145215 | 0.215615 | 1 |
| 15 | 94 | A_closed | +0.320721 | 0.034416 | 3 |
| 15 | 94 | A_open | +0.129764 | 0.324380 | 2 |
| 15 | 94 | I_feedback | +0.190957 | 0.312189 | 2 |
| 15 | 1409 | A_closed | -0.173011 | 0.075650 | 0 |
| 15 | 1409 | A_open | -0.165745 | 0.301371 | 1 |
| 15 | 1409 | I_feedback | -0.007266 | 0.296963 | 1 |
| 15 | 1410 | A_closed | -0.166942 | 0.073848 | 0 |
| 15 | 1410 | A_open | -0.130598 | 0.301204 | 1 |
| 15 | 1410 | I_feedback | -0.036344 | 0.295792 | 1 |

Means/SDs describe training-seed variability conditional on the fixed dataset and panel. No significance claim or confidence interval is attached to these three-run summaries.

## H94 and exact-cycle endpoint H1409

| Seed | Parent | Horizon | A_closed | A_open | I_feedback |
| --- | --- | --- | --- | --- | --- |
| 202 | 5 | 94 | -0.068724 | +0.071364 | -0.140088 |
| 202 | 5 | 1409 | +0.052303 | +0.012549 | +0.039755 |
| 202 | 15 | 94 | +0.300446 | -0.241957 | +0.542403 |
| 202 | 15 | 1409 | -0.177970 | -0.510910 | +0.332939 |
| 303 | 5 | 94 | -0.231192 | -0.103554 | -0.127638 |
| 303 | 5 | 1409 | -0.367308 | +0.001589 | -0.368897 |
| 303 | 15 | 94 | +0.360459 | +0.275753 | +0.084705 |
| 303 | 15 | 1409 | -0.095004 | +0.045183 | -0.140188 |
| 404 | 5 | 94 | +0.065704 | +0.135453 | -0.069749 |
| 404 | 5 | 1409 | -0.299780 | -0.100264 | -0.199516 |
| 404 | 15 | 94 | +0.301259 | +0.355497 | -0.054239 |
| 404 | 15 | 1409 | -0.246060 | -0.031509 | -0.214550 |

H1409 ends exactly 15 continuation domains; H1410 is the first update of the next domain because the focal candidate consumed the first batch. For seed 202 / block 5, A_open is +0.012549 at H1409 but -0.032782 at H1410. Thus even the replay-benefit component of the reproduced pattern depends on this adjacent endpoint. The closed acceptance harm and positive interaction occur at both points. All endpoints are retained.

Raw records for steps 1–94 have identical SHA256 entries across each short/long pair (282 records per pair), and shared audit metrics match exactly. This verifies shared prefixes; it does not create additional replication.

## Classification error and absolute trajectories

| Seed | Parent | Branch | Initial CE | Final CE | Initial error % | Final error % | Error change pp |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 202 | 5 | reject_closed | 3.01056 | 2.85585 | 63.53 | 53.00 | -10.53 |
| 202 | 5 | accept_closed | 2.98684 | 2.88883 | 61.33 | 51.73 | -9.60 |
| 202 | 5 | accept_replay | 2.98684 | 2.82306 | 61.33 | 52.60 | -8.73 |
| 202 | 15 | reject_closed | 3.04482 | 3.53186 | 54.07 | 56.60 | +2.53 |
| 202 | 15 | accept_closed | 3.07371 | 3.36175 | 54.20 | 56.67 | +2.47 |
| 202 | 15 | accept_replay | 3.07371 | 3.05786 | 54.20 | 53.00 | -1.20 |
| 303 | 5 | reject_closed | 2.83965 | 3.12211 | 59.13 | 57.07 | -2.07 |
| 303 | 5 | accept_closed | 2.72908 | 2.73403 | 58.20 | 52.87 | -5.33 |
| 303 | 5 | accept_replay | 2.72908 | 3.09921 | 58.20 | 56.80 | -1.40 |
| 303 | 15 | reject_closed | 3.24098 | 2.98554 | 55.53 | 52.40 | -3.13 |
| 303 | 15 | accept_closed | 3.06425 | 2.89398 | 54.13 | 53.60 | -0.53 |
| 303 | 15 | accept_replay | 3.06425 | 3.07443 | 54.13 | 53.13 | -1.00 |
| 404 | 5 | reject_closed | 2.87649 | 3.18919 | 58.67 | 55.80 | -2.87 |
| 404 | 5 | accept_closed | 2.85553 | 2.86872 | 57.87 | 52.20 | -5.67 |
| 404 | 5 | accept_replay | 2.85553 | 3.00496 | 57.87 | 52.07 | -5.80 |
| 404 | 15 | reject_closed | 2.94380 | 2.79756 | 51.73 | 50.53 | -1.20 |
| 404 | 15 | accept_closed | 2.92407 | 2.55841 | 52.00 | 49.73 | -2.27 |
| 404 | 15 | accept_replay | 2.92407 | 2.79087 | 52.00 | 51.47 | -0.53 |

CE and error must be interpreted separately. At seed 202 / block 5, closed acceptance has worse endpoint CE than rejection, but lower classification error (51.73% vs 53.00%). Unlike the original discovery runs, some new branches also have worse endpoint classification error than their own start (seed 202 / block 15 closed branches). Neither fact establishes a sustained trend. Absolute changes and accept/reject contrasts answer different questions.

![Block 5 full curves](fork_after5_all_seeds.png)

![Block 15 full curves](fork_after15_all_seeds.png)

## Additional exploratory process summary

| Seed | Parent | Mean A_closed | Mean A_open | Mean I_feedback |
| --- | --- | --- | --- | --- |
| 202 | 5 | +0.016295 | -0.085268 | +0.101563 |
| 202 | 15 | +0.001301 | -0.075392 | +0.076692 |
| 303 | 5 | +0.056013 | -0.041084 | +0.097097 |
| 303 | 15 | +0.026453 | -0.066764 | +0.093217 |
| 404 | 5 | +0.080110 | +0.089332 | -0.009222 |
| 404 | 15 | -0.034250 | +0.102382 | -0.136632 |

This is the equal-weight average over all 15 complete-domain endpoint audits (h=93,187,...,1409). It is a secondary, post-discovery descriptive summary, not a newly substituted primary endpoint, an exact time-integrated risk, or a moving-average trend test. Raw curves remain visible.

## Discovery seed kept separate

| Discovery seed | Parent | Immediate A_closed | H1410 A_closed | H1410 A_open | H1410 I_feedback |
| --- | --- | --- | --- | --- | --- |
| 101 | 5 | -0.045932 | +0.266292 | -0.050690 | +0.316982 |
| 101 | 15 | +0.046558 | +0.069601 | -0.052072 | +0.121673 |

Seed 101 motivated the follow-up and is not included in the new-seed means, SDs or counts. Its positive long-endpoint interactions coexist with opposite new-seed results.

## Interpretation and next decision

Supported: an immediate-to-later relative-harm reversal can occur in this specified system (discovery seed 101 and new seed 202 at block 5/H1410), and the realized effect depends on the supervision intervention. Not supported: consistently harmful feedback across seeds, persistent self-deterioration, a parameter-region map, or a spectral stability transition.

The most important update is that the apparent harmful pattern is not robust across these three new seeds. Do not tune a smoothing window, fork node or seed to recover a preferred narrative. Further work, if separately authorized, should first decide whether the target is an existence example or a reproducible regime; it should not start by fitting a Jacobian to these mixed trajectories.

## Artifacts and delivery

- [Frozen run contract](Run_Contract.md)
- [Verification record](Evidence/VERIFICATION.json)
- [All endpoint contrasts](endpoint_contrasts.csv)
- [Full recorded audit curves](full_audit_curves.csv)
- [Error and CE endpoints](endpoint_errors.csv)
- [Descriptive statistics](descriptive_statistics.json)
- [Artifact availability](ARTIFACTS.md)

GitHub delivery is pending. Only `experiment/C4` under `C4/` may be modified. Bulk raw evidence remains on Sapelo; no new release has been published for this batch.
