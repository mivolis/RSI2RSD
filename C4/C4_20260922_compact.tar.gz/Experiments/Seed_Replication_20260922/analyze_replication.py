"""Read-only analysis of verified C4 records; no training or checkpoint modification."""
from pathlib import Path
import csv, hashlib, json, statistics, datetime
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
BASE=Path(__file__).resolve().parent
ROOT=BASE/'Evidence/job48431715'
DISC=BASE/'Evidence/discovery_seed101'
SEEDS=[202,303,404];PARENTS=[5,15];BRANCHES=['reject_closed','accept_closed','accept_replay']
def read(p):return json.loads(p.read_text())
def dump(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
def table(headers,rows):
 return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+['| '+' | '.join(str(v) for v in r)+' |' for r in rows])
def fmt(x):return f'{x:+.6f}'
assert read(ROOT/'status.json')['status']=='complete'
checked=[];prefix=[];raw_records=0;hashed_files=0
for s in SEEDS:
 assert read(ROOT/f'parent_seed{s}/replication_verification.json')['status']=='verified'
 for b in PARENTS:
  for h in [94,1410]:
   p=ROOT/f'seed{s}_after{b}_h{h}';v=read(p/'verification.json');m=read(p/'complete.json')
   assert v['status']=='verified' and m['status']=='complete'
   raw_records+=v['raw_future_records'];hashed_files+=v['hashed_files']
   cfg=read(p/'config.json');assert cfg['seed']==s and cfg['after_block']==b and cfg['horizon']==h
   assert cfg['parent_config']['gamma']==1 and cfg['parent_config']['beta']==.001
   for rel,digest in m['files'].items():
    f=p/rel
    if f.exists():
     assert hashlib.sha256(f.read_bytes()).hexdigest()==digest,str(f)
     checked.append(str(f.relative_to(ROOT)))
  short=ROOT/f'seed{s}_after{b}_h94';long=ROOT/f'seed{s}_after{b}_h1410'
  sm=read(short/'complete.json')['files'];lm=read(long/'complete.json')['files']
  keys=[f'{br}/step_{i:04d}.npz' for br in BRANCHES for i in range(1,95)]
  assert all(sm[k]==lm[k] for k in keys)
  for br in BRANCHES:
   a=read(short/br/'metrics.json');z=read(long/br/'metrics.json')
   for k in set(a)&set(z):assert a[k]==z[k],(s,b,br,k)
  prefix.append(dict(seed=s,parent=b,raw_record_hashes_matching=282,shared_audit_metrics='exact match'))
verification=dict(status='all_12_forks_and_3_parents_verified',job=48431715,checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),remote_hashed_files=hashed_files,parent_hashed_files=3*1515,raw_future_records=raw_records,local_manifest_members_checked=checked,prefix_checks=prefix,supervisor_status=read(ROOT/'status.json'),scheduler_status='not independently checked: Operator VPN unavailable',scope='remote verifier checked full manifests and reconstructed raw metrics; local check covers downloaded manifest members and cross-horizon prefix hashes; no bulk second download')
dump(BASE/'Evidence/VERIFICATION.json',verification)
rows=[];curve=[];errors=[];domainmeans=[]
for s in SEEDS:
 for b in PARENTS:
  p=ROOT/f'seed{s}_after{b}_h1410';c=read(p/'comparison.json');short=read(ROOT/f'seed{s}_after{b}_h94/comparison.json')
  metrics={br:read(p/br/'metrics.json') for br in BRANCHES}
  initial=c[0]['A_closed']
  for r in c:
   vals={br:metrics[br][str(r['h'])]['student']['error'] for br in BRANCHES}
   curve.append(dict(seed=s,parent=b,h=r['h'],**{k:r[k] for k in ['reject_closed','accept_closed','accept_replay','A_closed','A_open','I_feedback']},**{br+'_error':v for br,v in vals.items()}))
  for r in [c[0],short[-1],next(x for x in c if x['h']==1409),c[-1]]:
   rows.append(dict(seed=s,parent=b,h=r['h'],immediate_A_closed=initial,**{k:r[k] for k in ['A_closed','A_open','I_feedback']},immediate_benefit=initial<0,closed_harm=r['A_closed']>0,feedback_penalty=r['I_feedback']>0))
  for br in BRANCHES:
   a=metrics[br]['0']['student'];z=metrics[br]['1410']['student']
   errors.append(dict(seed=s,parent=b,branch=br,initial_ce=a['ce'],final_ce=z['ce'],initial_error=a['error'],final_error=z['error'],error_change_pp=100*(z['error']-a['error'])))
  endrows=[r for r in c if r['h'] in [93+94*k for k in range(15)]];assert len(endrows)==15
  domainmeans.append(dict(seed=s,parent=b,**{k:statistics.mean(r[k] for r in endrows) for k in ['A_closed','A_open','I_feedback']}))
for name,data in [('endpoint_contrasts.csv',rows),('full_audit_curves.csv',curve),('endpoint_errors.csv',errors),('domain_endpoint_means_exploratory.csv',domainmeans)]:
 with (BASE/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
stats=[]
for b in PARENTS:
 for h in [94,1409,1410]:
  selected=[r for r in rows if r['parent']==b and r['h']==h]
  for k in ['A_closed','A_open','I_feedback']:
   vals=[r[k] for r in selected];stats.append(dict(parent=b,h=h,contrast=k,n=3,mean=statistics.mean(vals),sample_sd=statistics.stdev(vals),positive=sum(x>0 for x in vals)))
dump(BASE/'descriptive_statistics.json',stats)
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
colors={'reject_closed':'#3877b5','accept_closed':'#d86d20','accept_replay':'#32934b'}
for b in PARENTS:
 fig,axs=plt.subplots(3,3,figsize=(15,10),sharex=True)
 for i,s in enumerate(SEEDS):
  selected=[r for r in curve if r['seed']==s and r['parent']==b];hs=[r['h'] for r in selected]
  for br in BRANCHES:
   axs[i,0].plot(hs,[r[br] for r in selected],label=br,color=colors[br])
   axs[i,1].plot(hs,[100*r[br+'_error'] for r in selected],label=br,color=colors[br])
  for k,col in [('A_closed','#3877b5'),('A_open','#d86d20'),('I_feedback','#32934b')]:axs[i,2].plot(hs,[r[k] for r in selected],label=k,color=col)
  axs[i,2].axhline(0,color='black',lw=.7)
  for j,label in enumerate(['Fixed-panel student CE','Fixed-panel error (%)','Paired CE contrasts']):
   axs[i,j].set_title(f'Seed {s}: {label}');axs[i,j].grid(alpha=.2)
   if i==0:axs[i,j].legend(fontsize=8)
   if i==2:axs[i,j].set_xlabel('Future scheduled updates')
 fig.suptitle(f'C4 independent-seed replication: fork after block {b}\nRecorded audit points connected; no smoothing; CE and error may disagree',fontsize=14)
 fig.tight_layout(rect=(0,0,1,.93));fig.savefig(BASE/f'fork_after{b}_all_seeds.png',dpi=160);plt.close(fig)
fig,axs=plt.subplots(1,2,figsize=(11,4.5))
for ax,k,title in zip(axs,['A_closed','I_feedback'],['Accept vs reject under closed supervision','Closed vs replay interaction']):
 for i,b in enumerate(PARENTS):
  vals=[r[k] for r in rows if r['parent']==b and r['h']==1410]
  for offset,s,v in zip([-.12,0,.12],SEEDS,vals):ax.scatter(i+offset,v,label=f'Seed {s}' if i==0 else None,s=45,color={202:'#3877b5',303:'#d86d20',404:'#32934b'}[s])
  ax.scatter(i,statistics.mean(vals),marker='_',s=500,color='black',label='New-seed mean' if i==0 else None)
  disc=read(DISC/f'after{b}_h1410/comparison.json')[-1][k]
  ax.scatter(i+.24,disc,marker='x',color='#777777',s=65,label='Discovery seed 101' if i==0 else None)
 ax.axhline(0,color='black',lw=.7);ax.set_xticks([0,1]);ax.set_xticklabels(['After block 5','After block 15']);ax.set_ylabel('CE difference (positive = worse)');ax.set_title(title);ax.grid(axis='y',alpha=.2)
axs[0].legend(fontsize=8);fig.suptitle('H1410: three new seeds; discovery seed shown separately');fig.tight_layout();fig.savefig(BASE/'endpoint_replication.png',dpi=170);plt.close(fig)
endpoint=[r for r in rows if r['h']==1410]
texts=['# C4 independent-seed fork replication — 2026-09-22','''The original harmful long-endpoint pattern did **not** replicate consistently. At the block-5 parent, all three new candidate updates improve fixed-panel CE immediately, but only seed 202 becomes harmful relative to rejection at H1410. Seeds 303 and 404 remain beneficial, and their closed/replay interactions favor closed supervision. At block 15, all three closed acceptance effects are beneficial at H1410; the interaction is positive only for seed 202.

This is evidence of seed- and horizon-dependent effects, not a stable harmful-feedback law or persistent recursive deterioration. The new runs do not invalidate the observed discovery trajectory, but weaken its interpretation as a reproducible typical outcome.''','## Execution and evidence boundary',f'''Sapelo job 48431715 reports complete, with supervisor elapsed time {read(ROOT/'status.json')['elapsed_seconds']/60:.2f} minutes. All three parent trajectories and all 12 fork runs passed the retained independent verification records. Full remote verification covers {hashed_files:,} fork manifest members and {raw_records:,} future raw records, plus 4,545 parent manifest members. Local transferred manifest members and all six short/long raw prefixes were checked. Final Slurm accounting status/exit code is still pending because Operator VPN access is unavailable; file completion is not presented as a scheduler check.

Three **new exploratory training seeds**: 202, 303, 404. Lambda 1, beta .001, fixed pretrained source, original split and exploratory panel; confirmation audit untouched. Parent trajectories are regenerated from source initialization through 15 blocks. The first nonempty proposal after block 5/15 is used regardless of sign. No algorithm changes, seed filtering, parameter search or smoothed-trend selection occurred. H94 and H1410 share prefixes; they are not independent repetitions. The two parents within one seed are correlated. Seeds 303/404 must not later be described as fresh confirmation runs.

Core training/fork code is unchanged from the discovery run. The fixed panel contains 100 base images across 15 corruptions (1,500 image-corruption pairs), not 1,500 independent base images. Three seeds do not establish a population effect or precise failure frequency.''','## Comparisons','''All CE differences use the same panel; positive means worse.

- `A_closed = accept_closed - reject_closed`: total effect of accepting the focal update under endogenous supervision.
- `A_open = accept_replay - reject_replay`: acceptance effect under the rejection-generated supervision tape.
- `I_feedback = A_closed - A_open`: interaction with this specific intervention. Reject/replay reproduces the donor reject path; identity is explicitly checked over 20 steps.

Replay fixes pseudo-labels and confidence masks jointly. It is not a frozen teacher, an oracle target sequence, or a separation of label and mask mechanisms. Positive interaction alone does not imply accepting is worse than rejecting.''','## Primary H1410 results',table(['Seed','Parent','Immediate A_closed','H1410 A_closed','H1410 A_open','H1410 I_feedback'],[[r['seed'],r['parent'],fmt(r['immediate_A_closed']),fmt(r['A_closed']),fmt(r['A_open']),fmt(r['I_feedback'])] for r in endpoint]),'''- Block 5: 3/3 immediate CE improvements; 1/3 harmful closed acceptance endpoints; 1/3 positive feedback interactions. Seed 202 reproduces the discovery sign pattern at H1410.
- Block 15: 2/3 immediate CE improvements (seed 202 is immediately harmful); 0/3 harmful closed acceptance endpoints; 1/3 positive interactions. Seed 202 has positive interaction while acceptance is nevertheless beneficial relative to rejection.
- These counts summarize three runs per parent; they are not estimated universal probabilities. Do not combine both parents into six independent seeds.''','![H1410 replication](endpoint_replication.png)','## Descriptive variation across the three new seeds',table(['Parent','Horizon','Contrast','Mean','Sample SD','Positive / 3'],[[r['parent'],r['h'],r['contrast'],fmt(r['mean']),f"{r['sample_sd']:.6f}",r['positive']] for r in stats]),'Means/SDs describe training-seed variability conditional on the fixed dataset and panel. No significance claim or confidence interval is attached to these three-run summaries.','## H94 and exact-cycle endpoint H1409',table(['Seed','Parent','Horizon','A_closed','A_open','I_feedback'],[[r['seed'],r['parent'],r['h'],fmt(r['A_closed']),fmt(r['A_open']),fmt(r['I_feedback'])] for r in rows if r['h'] in [94,1409]]),'''H1409 ends exactly 15 continuation domains; H1410 is the first update of the next domain because the focal candidate consumed the first batch. For seed 202 / block 5, A_open is +0.012549 at H1409 but -0.032782 at H1410. Thus even the replay-benefit component of the reproduced pattern depends on this adjacent endpoint. The closed acceptance harm and positive interaction occur at both points. All endpoints are retained.

Raw records for steps 1–94 have identical SHA256 entries across each short/long pair (282 records per pair), and shared audit metrics match exactly. This verifies shared prefixes; it does not create additional replication.''','## Classification error and absolute trajectories',table(['Seed','Parent','Branch','Initial CE','Final CE','Initial error %','Final error %','Error change pp'],[[r['seed'],r['parent'],r['branch'],f"{r['initial_ce']:.5f}",f"{r['final_ce']:.5f}",f"{100*r['initial_error']:.2f}",f"{100*r['final_error']:.2f}",f"{r['error_change_pp']:+.2f}"] for r in errors]),'''CE and error must be interpreted separately. At seed 202 / block 5, closed acceptance has worse endpoint CE than rejection, but lower classification error (51.73% vs 53.00%). Unlike the original discovery runs, some new branches also have worse endpoint classification error than their own start (seed 202 / block 15 closed branches). Neither fact establishes a sustained trend. Absolute changes and accept/reject contrasts answer different questions.''','![Block 5 full curves](fork_after5_all_seeds.png)','![Block 15 full curves](fork_after15_all_seeds.png)','## Additional exploratory process summary',table(['Seed','Parent','Mean A_closed','Mean A_open','Mean I_feedback'],[[r['seed'],r['parent'],fmt(r['A_closed']),fmt(r['A_open']),fmt(r['I_feedback'])] for r in domainmeans]),'''This is the equal-weight average over all 15 complete-domain endpoint audits (h=93,187,...,1409). It is a secondary, post-discovery descriptive summary, not a newly substituted primary endpoint, an exact time-integrated risk, or a moving-average trend test. Raw curves remain visible.''','## Discovery seed kept separate',table(['Discovery seed','Parent','Immediate A_closed','H1410 A_closed','H1410 A_open','H1410 I_feedback'],[[101,b,fmt(read(DISC/f'after{b}_h1410/comparison.json')[0]['A_closed']),*[fmt(read(DISC/f'after{b}_h1410/comparison.json')[-1][k]) for k in ['A_closed','A_open','I_feedback']]] for b in PARENTS]),'''Seed 101 motivated the follow-up and is not included in the new-seed means, SDs or counts. Its positive long-endpoint interactions coexist with opposite new-seed results.''','## Interpretation and next decision','''Supported: an immediate-to-later relative-harm reversal can occur in this specified system (discovery seed 101 and new seed 202 at block 5/H1410), and the realized effect depends on the supervision intervention. Not supported: consistently harmful feedback across seeds, persistent self-deterioration, a parameter-region map, or a spectral stability transition.

The most important update is that the apparent harmful pattern is not robust across these three new seeds. Do not tune a smoothing window, fork node or seed to recover a preferred narrative. Further work, if separately authorized, should first decide whether the target is an existence example or a reproducible regime; it should not start by fitting a Jacobian to these mixed trajectories.''','## Artifacts and delivery','''- [Frozen run contract](Run_Contract.md)
- [Verification record](Evidence/VERIFICATION.json)
- [All endpoint contrasts](endpoint_contrasts.csv)
- [Full recorded audit curves](full_audit_curves.csv)
- [Error and CE endpoints](endpoint_errors.csv)
- [Descriptive statistics](descriptive_statistics.json)
- [Artifact availability](ARTIFACTS.md)

GitHub delivery is pending. Only `experiment/C4` under `C4/` may be modified. Bulk raw evidence remains on Sapelo; no new release has been published for this batch.''']
(BASE/'RESULTS.md').write_text('\n\n'.join(texts)+'\n')
print('verified',len(checked),'local manifest members;',raw_records,'remote raw future records')
print('H1410 descriptive',json.dumps([r for r in stats if r['h']==1410],indent=2))
