# C4 seed replication: artifact availability

## Verified local evidence
- [RESULTS.md](RESULTS.md): English interpretation, all endpoint tables and limitations.
- [endpoint_replication.png](endpoint_replication.png): three new seeds, discovery seed separate.
- [fork_after5_all_seeds.png](fork_after5_all_seeds.png), [fork_after15_all_seeds.png](fork_after15_all_seeds.png): all recorded CE/error/contrast trajectories, no smoothing.
- CSVs: endpoint contrasts, full audit curves, endpoint errors, secondary domain-endpoint means.
- [Evidence/VERIFICATION.json](Evidence/VERIFICATION.json): remote verifier coverage, local downloaded-member hashes, exact shared-prefix checks.
- `Evidence/job48431715/`: completion manifests, independent verification records, configurations, schedules, per-branch metrics, runtime, logs and unchanged core code snapshots. Partial-record counts in older snapshot files are superseded by VERIFICATION.json.
- `Evidence/discovery_seed101/`: two previously verified comparison tables, used only as the separately identified discovery reference.
- `analyze_replication.py`: reproduce tables/figures from these compact files using Python, NumPy and Matplotlib. No GPU or training needed.
- `seed_replication_20260922.py` / `.sbatch`: submitted batch supervisor and resource request.

## Canonical remote raw evidence
Sapelo root: `/scratch/yz54720/RSI2RSD/C4/seed_replication_20260922/job48431715/`.

Each `seed{202,303,404}_after{5,15}_h{94,1410}/` retains full checkpoints, candidate records, all per-step supervision/predictions and audit logits. Parent runs are `parent_seed{202,303,404}/`. All three parents and all twelve forks have successful verification records. No bulk checkpoint/prediction download was performed for this batch. Keep these remote files; scratch is not represented as permanent archival storage.

Transfer: authenticated rsync through `xfer.gacrc.uga.edu`, filtered to compact JSON, logs, code and figures. All locally present members of completed fork manifests were SHA256 checked. Short/long raw prefix equality uses matching remote manifest hashes (282 records per pair), alongside exact shared audit metrics. This is not a second full raw-data download.

## External accounting and publication
Slurm accounting was read after Operator access recovered: job 48431715 is `COMPLETED 0:0`, elapsed 01:09:34. The raw accounting row is retained in `../Dynamics_Completion_20260922/Evidence/SCHEDULER_FINAL_20260922.tsv`. The earlier VPN-pending note is superseded. The previously used signed-in browser remains the GitHub publication route.

GitHub publication for this batch is **pending**, not available yet. Target only `mivolis/RSI2RSD`, branch `experiment/C4`, directory `C4/Seed_Replication_20260922/`. Do not change `main` or replace old discovery releases.

`C4_seed_replication_20260922_compact.tar.gz` is a local staging archive, not a published release. Its included per-file manifest supports round-trip verification. Raw checkpoints are excluded.
