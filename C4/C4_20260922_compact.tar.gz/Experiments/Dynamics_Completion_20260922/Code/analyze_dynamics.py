"""Fit only projected directions with adequate rank; preserve failed identification."""
import json,sys
from pathlib import Path
import numpy as np

def analyze(path):
 p=Path(path);rs=json.loads((p/'responses.json').read_text());good=[r for r in rs if r['xH'] is not None]
 base={(r['family'],r['tape']):r for r in good if r['obj']=='base'}
 switches=[]
 for r in good:
  if r['obj']=='base':continue
  b=base.get((r['family'],r['tape']))
  if b is None:continue
  counts=dict(name=r['name'],examples=0,label_switches=0,mask_switches=0)
  for f in sorted((p/r['name']).glob('step_*.npz')):
   donor=p/b['name']/f.name
   if not donor.exists():continue
   with np.load(f) as x,np.load(donor) as y:
    counts['examples']+=int(x['pseudo'].size)
    counts['label_switches']+=int(np.sum(x['pseudo']!=y['pseudo']))
    counts['mask_switches']+=int(np.sum(x['mask']!=y['mask']))
  switches.append(counts)

 train=[r for r in good if r['family']=='train' and r['obj']!='base']
 displacements=[np.array(r['x0'])-base[(r['family'],r['tape'])]['x0'] for r in train]
 if not displacements:return {'status':'unidentifiable','reason':'no finite training perturbations'}
 scale=np.sqrt(np.mean(np.square(displacements),axis=0));resolution=np.max([r['resolution'] for r in rs],axis=0)
 resolved=scale>resolution
 base_values=[r for r in good if r['family']=='train' and r['obj']=='base']
 F=np.array([r['xH'] for r in base_values])
 result=dict(hard_switches=switches,F_at_parent=F.mean(0).tolist(),F_tape_sd=F.std(0,ddof=1).tolist() if len(F)>1 else None,F_tapes=len(F),state_rms=scale.tolist(),evaluation_resolution=resolution.tolist(),coordinate_resolved=resolved.tolist(),finite_responses=len(good),total_responses=len(rs),fits={},gains=[])
 if not resolved.all():
  result.update(status='unidentifiable',reason='one or more zero/unresolved coordinate scales');return result
 W=1/scale;result['W_diagonal']=W.tolist()
 for r in good:
  if r['obj']=='base':continue
  b=base[(r['family'],r['tape'])];dx=np.array(r['x0'])-b['x0'];dy=np.array(r['xH'])-b['xH']
  norm=float(np.linalg.norm(W*dx));resolved_start=np.any(np.abs(dx)>resolution)
  result['gains'].append(dict(name=r['name'],gain=float(np.linalg.norm(W*dy)/norm) if resolved_start and norm>0 else None,reason=None if resolved_start and norm>0 else 'unresolved initial separation'))
 for eps in [1e-4,3e-4]:
  X=[];Y=[]
  for direction in range(8):
   dx=[];dy=[]
   for tape in [91001,91002,91003]:
    pairs={r['sign']:r for r in train if r['epsilon']==eps and r['direction']==direction and r['tape']==tape}
    if set(pairs)!={-1,1}:continue
    dx.append((np.array(pairs[1]['x0'])-pairs[-1]['x0'])/2);dy.append((np.array(pairs[1]['xH'])-pairs[-1]['xH'])/2)
   if len(dx)==3:X.append(np.mean(dx,axis=0));Y.append(np.mean(dy,axis=0))
  if len(X)!=8:
   result['fits'][str(eps)]={'status':'unidentifiable','reason':'missing finite paired directions'};continue
  X=np.array(X).T;Y=np.array(Y).T;Xs=W[:,None]*X;Ys=W[:,None]*Y
  rank=int(np.linalg.matrix_rank(Xs));cond=float(np.linalg.cond(Xs));fit=dict(rank=rank,condition=cond if np.isfinite(cond) else None,singular_values=np.linalg.svd(Xs,compute_uv=False).tolist())
  if rank!=4 or cond>1e3:
   fit.update(status='unidentifiable',reason='rank/conditioning screen failed');result['fits'][str(eps)]=fit;continue
  Js=Ys@Xs.T@np.linalg.inv(Xs@Xs.T);J=Js*W[None,:]/W[:,None]
  residual=[];identity=[];zero=[];momentum=[]
  for r in good:
   if r['family']!='validation' or r['obj']=='base':continue
   b=base[(r['family'],r['tape'])];dx=np.array(r['x0'])-b['x0'];dy=np.array(r['xH'])-b['xH']
   if r['obj']=='momentum':
    momentum.append(dict(name=r['name'],same_initial_projection=bool(np.all(np.abs(dx)<=resolution)),future_resolved=bool(np.any(np.abs(dy)>resolution)),future_norm=float(np.linalg.norm(W*dy))));continue
   residual.append(float(np.linalg.norm(W*(dy-J@dx))));identity.append(float(np.linalg.norm(W*(dy-dx))));zero.append(float(np.linalg.norm(W*dy)))
  complete_validation=len(residual)==24 and len(momentum)==6
  prediction_pass=complete_validation and np.mean(residual)<min(np.mean(identity),np.mean(zero))
  closure_fail=any(v['same_initial_projection'] and v['future_resolved'] for v in momentum)
  fit.update(status='candidate_fit',candidate_J=J.tolist(),standardized_J=Js.tolist(),validation_count=len(residual),validation_residuals=residual,identity_residuals=identity,no_response_residuals=zero,prediction_pass=bool(prediction_pass),momentum_checks=momentum,closure_falsified=closure_fail)
  result['fits'][str(eps)]=fit
 fits=list(result['fits'].values());eligible=len(fits)==2 and all(f.get('status')=='candidate_fit' for f in fits)
 if eligible:
  j1,j2=[np.array(f['standardized_J']) for f in fits];den=max(np.linalg.norm(j1),np.linalg.norm(j2));diff=float(np.linalg.norm(j1-j2)/den) if den>0 else 0.
  result['relative_scale_difference']=diff;result['scale_screen_threshold']=.25
  identified=diff<=.25 and all(f['prediction_pass'] and not f['closure_falsified'] for f in fits)
  result['status']='locally_supported_exploratory_fit' if identified else 'unidentifiable'
  if identified:
   result['J']=fits[0]['candidate_J'];result['spectral_radius']=float(max(abs(np.linalg.eigvals(np.array(result['J'])))))
   result['interpretation']='Exploratory phase-specific derivative only; no established fixed point, no stability or risk-sign certificate.'
 else:result['status']='unidentifiable'
 return result
if __name__=='__main__':
 p=Path(sys.argv[1]);result=analyze(p);(p/'dynamics_analysis.json').write_text(json.dumps(result,indent=2,allow_nan=False))
