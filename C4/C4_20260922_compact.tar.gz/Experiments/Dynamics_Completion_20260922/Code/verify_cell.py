import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from c4 import filehash,atomic_json
p=Path(sys.argv[1]);checked=0;markers=[]
for pattern in ['dynamics_b*/complete.json','extension/block_*/attempt_*/complete.json']:
 for marker in p.glob(pattern):
  m=json.loads(marker.read_text())
  for name,digest in m.get('files',{}).items():
   assert filehash(marker.parent/name)==digest,(marker,name)
   checked+=1
  markers.append(str(marker.relative_to(p)))
atomic_json(p/'verification.json',dict(status='verified_existing_manifests',hashed_files=checked,markers=markers,note='Does not imply missing components completed; consult status and coverage.'))
