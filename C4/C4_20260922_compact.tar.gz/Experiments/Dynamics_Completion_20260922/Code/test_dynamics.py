import ast,copy,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import torch
from c4 import Learner
from forks import snapshot,restore
from run_dynamics import perturb
r=Path(__file__).resolve().parents[1]
a=ast.parse((r/'c4.py').read_text());b=ast.parse((r/'dynamics_v1/extend_trajectory.py').read_text())
for name in ['Learner','fixed_audit','audit','strong_transform','split_ids']:
 x=next(n for n in a.body if getattr(n,'name',None)==name);y=next(n for n in b.body if getattr(n,'name',None)==name)
 assert ast.dump(x)==ast.dump(y),name
m=torch.nn.Linear(3,2);l=Learner(m,.5)
for p in l.student.parameters():l.opt.state[p]['momentum_buffer']=torch.ones_like(p)
s=snapshot(l)
for obj in ['student','teacher','mixed','momentum']:
 perturb(l,s,obj,0,1e-4,1);plus=snapshot(l)
 perturb(l,s,obj,0,1e-4,-1);minus=snapshot(l)
 for key in ['student','teacher']:
  for k in s[key]:
   assert torch.allclose((plus[key][k]+minus[key][k])/2,s[key][k],atol=1e-7)
   if obj=='momentum' or (obj not in [key,'mixed']):assert torch.equal(plus[key][k],s[key][k])
 restore(l,s)
 assert all(torch.equal(v,s['student'][k]) for k,v in l.student.state_dict().items())
print('PASS: core learner equality, intervention targeting, symmetric perturbations, immutable restore')
import subprocess
subprocess.run([sys.executable,str(Path(__file__).with_name('test_analysis.py'))],check=True)
