import json,os,subprocess,sys,shutil,time
from pathlib import Path
ROOT=Path('/scratch/yz54720/RSI2RSD/C4');os.chdir(ROOT)
task=int(os.environ['SLURM_ARRAY_TASK_ID']);point=task//2 if task<12 else task-12;seed=[202,303][task%2] if task<12 else 404
points=[(1.,.001),(1.,.01),(.5,.001),(.5,.01),(0.,.001),(0.,.01)];lam,beta=points[point]
if point==0:parent=ROOT/f'seed_replication_20260922/job48431715/parent_seed{seed}'
else:
 arr='48445435' if seed!=404 else '48445442';matches=list((ROOT/f'grid_single_replication_20260922/array{arr}').glob(f'point{point-1}_seed{seed}_job*/parent_seed{seed}'))
 assert len(matches)==1,matches;parent=matches[0]
out=ROOT/f'dynamics_v1/results/array{os.environ["SLURM_ARRAY_JOB_ID"]}/point{point}_seed{seed}_job{os.environ["SLURM_JOB_ID"]}';out.mkdir(parents=True,exist_ok=False)
(out/'code').mkdir()
for p in (ROOT/'dynamics_v1').glob('*.py'):shutil.copy2(p,out/'code'/p.name)
for name in ['c4.py','forks.py']:shutil.copy2(ROOT/name,out/'code'/name)
record=dict(point=point,seed=seed,gamma=[lam,beta],parent=str(parent),task=task,job=os.environ['SLURM_JOB_ID'],components={})
def save(): (out/'status.json').write_text(json.dumps(record,indent=2))
def call(name,args):
 with (out/(name+'.log')).open('w') as log:r=subprocess.run([sys.executable]+args,stdout=log,stderr=subprocess.STDOUT)
 record['components'][name]={'exit_code':r.returncode};save();return r.returncode
save()
for block in [5,15]:
 if not list((parent/f'block_{block-1:03d}').glob('attempt_*/complete.json')):
  record['components'][f'dynamics_b{block}']={'status':'unavailable_parent'};save();continue
 dest=out/f'dynamics_b{block}'
 code=call(f'dynamics_b{block}',['dynamics_v1/run_dynamics.py','--parent',str(parent),'--output',str(dest),'--block',str(block)])
 if code==0:call(f'analysis_b{block}',['dynamics_v1/analyze_dynamics.py',str(dest)])
if list((parent/'block_014').glob('attempt_*/complete.json')):
 call('extension',['dynamics_v1/extend_trajectory.py','--data','data/CIFAR-100-C','--output',str(out/'extension'),'--resume-parent',str(parent),'--gamma',str(lam),'--beta',str(beta),'--seed',str(seed),'--cycles','3'])
else:record['components']['extension']={'status':'unavailable_parent'}
call('verification',['dynamics_v1/verify_cell.py',str(out)])
record['status']='finished_components_require_coverage_review';save()
# Numerical failures stay visible. A supervisor success is never a scientific completion marker.
