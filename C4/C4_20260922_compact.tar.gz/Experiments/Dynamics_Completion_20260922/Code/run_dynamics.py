"""Paired state interventions, frozen C4 learner, exploratory projection."""
import argparse,json,sys,time,traceback
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
import torch
from c4 import Learner,MODEL,split_ids,reference_ids,reference_images,fixed_audit,strong_transform,atomic_json,filehash
from forks import snapshot,restore,schedule,views,save_step

def perturb(learner,base,obj,direction,eps,sign):
    restore(learner,base)
    gen=torch.Generator().manual_seed(870000+direction)
    with torch.no_grad():
        for target in (['student','teacher'] if obj=='mixed' else [obj]):
            if target=='momentum':
                pairs=[(learner.opt.state[p].get('momentum_buffer'),a) for p,a in zip(learner.student.parameters(),learner.anchor.parameters())]
            else:pairs=list(zip(getattr(learner,target).parameters(),learner.anchor.parameters()))
            for value,anchor in pairs:
                if value is None:continue
                v=torch.randn(value.shape,generator=gen).to(value.device)
                scale=float(value.norm()) or float(anchor.norm())
                if scale:value.add_(v,alpha=sign*eps*scale/float(v.norm()))

def run(a):
    torch.set_num_threads(4);torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False;torch.use_deterministic_algorithms(True)
    parent=Path(a.parent);out=Path(a.output);out.mkdir(parents=True,exist_ok=False)
    cfg=json.loads((parent/'config.json').read_text());markers=list((parent/f'block_{a.block-1:03d}').glob('attempt_*/complete.json'))
    if len(markers)!=1:
        atomic_json(out/'status.json',dict(status='unavailable_parent',parent=str(parent),block=a.block));return
    marker=markers[0];ckpt=marker.parent/'checkpoint.pt'
    assert filehash(ckpt)==json.loads(marker.read_text())['files']['checkpoint.pt']
    from robustbench.utils import load_model
    source=load_model(model_name=MODEL,dataset='cifar100',threat_model='corruptions',model_dir='checkpoints').eval().cuda()
    learner=Learner(source,cfg['gamma'],alpha=cfg['alpha']);learner.restore(ckpt,cfg);base=snapshot(learner)
    labels=np.load(Path(a.data)/'labels.npy')[:10000];pools=split_ids(labels);ids=reference_ids(pools,labels);panel=reference_images(a.data,ids)
    config=dict(parent=str(parent),parent_sha256=filehash(ckpt),parent_block=a.block,gamma=cfg['feedback_vector'],seed=cfg['seed'],lag=a.horizon,scales=[1e-4,3e-4],tapes=[91001,91002,91003],validation_tapes=[92001,92002,92003],command=sys.argv,code_sha256=filehash(__file__))
    atomic_json(out/'config.json',config)
    anchor=None;records=[];transform=strong_transform();start=time.time()
    design=[('train','base',-1,0.,0)]
    for obj,offset in [('student',0),('teacher',4)]:
        for d in range(offset,offset+4):
            for eps in config['scales']:
                for sign in [-1,1]:design.append(('train',obj,d,eps,sign))
    design.append(('validation','base',-1,0.,0))
    for d in range(100,104):
        for sign in [-1,1]:design.append(('validation','mixed',d,1e-4,sign))
    for sign in [-1,1]:design.append(('validation','momentum',200,1e-4,sign))
    if a.smoke:design=[('train','base',-1,0.,0),('train','student',0,1e-4,1),('validation','momentum',200,1e-4,1)]
    for family,obj,d,eps,sign in design:
        tapes=config['tapes'] if family=='train' else config['validation_tapes']
        if a.smoke:tapes=tapes[:1]
        for tape in tapes:
            name=f'{family}_{obj}_d{d}_e{eps}_s{sign}_t{tape}';dest=out/name;dest.mkdir()
            restore(learner,base)
            if obj!='base':perturb(learner,base,obj,d,eps,sign)
            learner.save(dest/'initial.pt',a.block,config)
            initial,anchor=fixed_audit(learner,panel,ids,labels,'cuda',dest/'q_initial.npz',anchor)
            repeat,_=fixed_audit(learner,panel,ids,labels,'cuda',dest/'q_repeat.npz',anchor)
            seq=schedule(a.block,0,a.horizon,tape,pools);atomic_json(dest/'schedule.json',seq)
            metrics={'0':initial};rows=[];error=None
            try:
                for step,item in enumerate(seq,1):
                    weak,strong=views(a.data,item,'cuda',transform);values=learner.step(weak,strong)
                    rows.append(save_step(dest/f'step_{step:04d}.npz',item,values,labels))
                final,_=fixed_audit(learner,panel,ids,labels,'cuda',dest/'q_final.npz',anchor);metrics[str(a.horizon)]=final
            except FloatingPointError as ex:
                error=repr(ex);(dest/'failure.txt').write_text(traceback.format_exc())
            learner.save(dest/'final_or_failed.pt',a.block,config)
            atomic_json(dest/'updates.json',rows);atomic_json(dest/'metrics.json',metrics)
            records.append(dict(name=name,family=family,obj=obj,direction=d,epsilon=eps,sign=sign,tape=tape,x0=initial['diagnostic_state'],resolution=np.abs(np.array(initial['diagnostic_state'])-repeat['diagnostic_state']).tolist(),xH=metrics.get(str(a.horizon),{}).get('diagnostic_state'),error=error))
            atomic_json(out/'responses.json',records)
            atomic_json(dest/'complete.json',dict(status='numerical_failure' if error else 'complete',files={str(p.relative_to(dest)):filehash(p) for p in dest.iterdir() if p.is_file() and p.name!='complete.json'}))
            atomic_json(out/'status.json',dict(status='running',completed=len(records),elapsed_seconds=time.time()-start))
    atomic_json(out/'complete.json',dict(status='complete_with_failures' if any(r['error'] for r in records) else 'complete',responses=len(records),elapsed_seconds=time.time()-start,files={str(p.relative_to(out)):filehash(p) for p in out.rglob('*') if p.is_file() and p.name not in ['complete.json','status.json']}))
    atomic_json(out/'status.json',dict(status='complete',responses=len(records),elapsed_seconds=time.time()-start))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--parent',required=True);p.add_argument('--output',required=True);p.add_argument('--block',type=int,choices=[5,15],required=True);p.add_argument('--horizon',type=int,default=20);p.add_argument('--data',default='data/CIFAR-100-C');p.add_argument('--smoke',action='store_true');run(p.parse_args())
