import tempfile,json
from pathlib import Path
import numpy as np
from analyze_dynamics import analyze
rng=np.random.default_rng(15);A=np.diag([.2,.4,.6,.8]);rows=[];x=np.array([2.,1.,.2,.8])
for family,tapes in [('train',[91001,91002,91003]),('validation',[92001,92002,92003])]:
 for tape in tapes:
  rows.append(dict(name=f'b{tape}',family=family,obj='base',direction=-1,epsilon=0,sign=0,tape=tape,x0=x.tolist(),xH=(A@x).tolist(),resolution=[0]*4,error=None))
for d in range(8):
 v=rng.normal(size=4)
 for eps in [1e-4,3e-4]:
  for sign in [-1,1]:
   for tape in [91001,91002,91003]:
    z=x+sign*eps*v;rows.append(dict(name=f'{d}{eps}{sign}{tape}',family='train',obj='student',direction=d,epsilon=eps,sign=sign,tape=tape,x0=z.tolist(),xH=(A@z).tolist(),resolution=[0]*4,error=None))
for d in range(4):
 v=rng.normal(size=4)
 for sign in [-1,1]:
  for tape in [92001,92002,92003]:
   z=x+sign*1e-4*v;rows.append(dict(name=f'v{d}{sign}{tape}',family='validation',obj='mixed',direction=d,epsilon=1e-4,sign=sign,tape=tape,x0=z.tolist(),xH=(A@z).tolist(),resolution=[0]*4,error=None))
for sign in [-1,1]:
 for tape in [92001,92002,92003]:rows.append(dict(name=f'm{sign}{tape}',family='validation',obj='momentum',direction=200,epsilon=1e-4,sign=sign,tape=tape,x0=x.tolist(),xH=(A@x).tolist(),resolution=[0]*4,error=None))
with tempfile.TemporaryDirectory() as d:
 p=Path(d);(p/'responses.json').write_text(json.dumps(rows));r=analyze(p);assert r['status']=='locally_supported_exploratory_fit',r
 assert np.max(np.abs(np.array(r['J'])-A))<1e-8
 for row in rows:row['x0'][3]=.8;row['xH'][3]=.8
 (p/'responses.json').write_text(json.dumps(rows));assert analyze(p)['status']=='unidentifiable'
print('PASS: recovers known full-rank map; rejects unresolved projection')
