#!/usr/bin/env python3
"""Build the final 18-cell C4 report from locally mirrored, verified evidence.

This script does no training and never reads the untouched confirmation audit.
Run with the Codex bundled Python, which supplies reportlab.
"""

import csv
import json
import math
import statistics
from pathlib import Path
from xml.sax.saxutils import escape

from reportlab.graphics.shapes import Circle, Drawing, Line, PolyLine, Rect, String
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    KeepTogether,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)


HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]
GRID = PROJECT / "Experiments/Parameter_Grid_20260922/Evidence/compact"
BASE = PROJECT / "Experiments/Seed_Replication_20260922/Evidence/job48431715"
DYN = HERE / "Evidence"
OUT = HERE / "Final_2026-09-22"
OUT.mkdir(exist_ok=True)
PDF = HERE / "C4_Results_Full_2026-09-22_EN.pdf"
CUTOFF = "2026-09-22 20:52 EDT; all scheduled cells terminal and audited"
POINTS = [(1.0, .001), (1.0, .01), (.5, .001), (.5, .01), (0.0, .001), (0.0, .01)]
GRID_POINT = {1: 0, 2: 1, 3: 2, 4: 3, 5: 4}
FULL = {(p, s) for p in (0, 2, 4, 5) for s in (202, 303, 404)}
RUNNING = set()
SOURCE_CE = 2.452554941177368
SOURCE_ERROR = .4546666741371155


def read(path):
    return json.loads(Path(path).read_text())


def fmt(x, digits=3):
    return "-" if x is None else f"{x:.{digits}f}"


def gamma(p):
    a, b = POINTS[p]
    return f"({a:g}, {b:g})"


def label(p, seed):
    return f"{gamma(p)} / {seed}"


def one(glob):
    hits = list(glob)
    assert len(hits) == 1, (len(hits), hits[:3])
    return hits[0]


def parent_path(p, seed):
    if p == 0:
        return BASE / f"parent_seed{seed}"
    arr = "48445435" if seed != 404 else "48445442"
    return one(GRID.glob(f"array{arr}/point{GRID_POINT[p]}_seed{seed}_job*/parent_seed{seed}"))


def grid_cell_path(p, seed):
    if p == 0:
        return BASE
    arr = "48445435" if seed != 404 else "48445442"
    return one(GRID.glob(f"array{arr}/point{GRID_POINT[p]}_seed{seed}_job*"))


def dyn_path(p, seed):
    array = "48452662" if seed != 404 else "48452757"
    return one((DYN / f"array{array}").glob(f"point{p}_seed{seed}_job*"))


def summaries(path):
    return {read(f)["block"]: read(f) for f in path.glob("block_*/attempt_*/summary.json")}


def update_rows(path):
    rows = []
    for f in sorted(path.glob("block_*/attempt_*/updates.jsonl")):
        rows.extend(json.loads(line) for line in f.read_text().splitlines() if line.strip())
    return rows


def concentration(counts):
    total = sum(counts)
    if not total:
        return None
    return 1 - sum(-v / total * math.log(v / total) for v in counts if v) / math.log(100)


def write_csv(name, rows):
    path = OUT / name
    if rows:
        keys = list(rows[0])
        with path.open("w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=keys)
            w.writeheader()
            w.writerows(rows)
    return path


def collect():
    coverage, signs, cycles, blocks, sweep, forks, dynamics, xt, probes_out, immediate = ([] for _ in range(10))
    probe_points = {}
    trajectory = {}
    failure_rows = []

    for p, (lam, beta) in enumerate(POINTS):
        for seed in (202, 303, 404):
            parent = parent_path(p, seed)
            if p in (1, 3):
                base = grid_cell_path(p, seed)
                assert read(base / "status.json")["status"] == "failed"
                ncomplete = len(list(parent.glob("block_*/attempt_*/complete.json")))
                assert ncomplete < 5
                coverage.append(dict(gamma=gamma(p), seed=seed, parent=f"Numerical failure ({ncomplete} completed blocks)",
                                     forks="Unavailable", three_cycle="Unavailable", H20_J="Unavailable",
                                     C4_1_to_4="Unavailable", C4_5="Unavailable", C4_6="Unavailable", C4_7="Failure cell"))
                failure_rows.append(dict(gamma=gamma(p), seed=seed, completed_blocks=ncomplete,
                                         failure="nonfinite post-update loss", source=str(base)))
                continue

            ps = summaries(parent)
            assert sorted(ps) == list(range(15)), (p, seed, sorted(ps))
            if p == 0:
                assert read(parent / "replication_verification.json")["status"] in ("verified", "complete")
            else:
                assert read(parent / "status.json")["status"] == "complete"

            full = (p, seed) in FULL
            if full:
                dpath = dyn_path(p, seed)
                status = read(dpath / "status.json")
                verify = read(dpath / "verification.json")
                assert all(status["components"][k]["exit_code"] == 0 for k in
                           ("dynamics_b5", "analysis_b5", "dynamics_b15", "analysis_b15", "extension", "verification"))
                assert verify["status"] == "verified_existing_manifests" and len(verify["markers"]) == 32
                assert verify["hashed_files"] == 10426
                es = summaries(dpath / "extension")
                assert sorted(es) == list(range(15, 45))
                all_blocks = {**ps, **es}
                assert sorted(all_blocks) == list(range(45))
                all_updates = update_rows(parent) + update_rows(dpath / "extension")
                assert len(all_updates) == 45 * 94, (p, seed, len(all_updates))
                updates_by_block = {i: [r for r in all_updates if r["block"] == i] for i in range(45)}
                assert all(len(v) == 94 for v in updates_by_block.values())
                three, h20, c14 = "Verified", "Finite; J not identified", "Verified (3 cycles)"
            elif (p, seed) in RUNNING:
                three, h20, c14 = "Running", "Running", "Running (not reported)"
            else:
                three, h20, c14 = "Queued", "Queued", "Queued (not reported)"
            coverage.append(dict(gamma=gamma(p), seed=seed, parent="Verified (1 cycle)", forks="Verified",
                                 three_cycle=three, H20_J=h20, C4_1_to_4=c14,
                                 C4_5="Verified forks", C4_6=h20, C4_7="Descriptive only"))

            # C4-5 is a separate, completed one-cycle branch archive for all 12 viable cells.
            for node in (5, 15):
                short = grid_cell_path(p, seed) / f"seed{seed}_after{node}_h94"
                root = grid_cell_path(p, seed) / f"seed{seed}_after{node}_h1410"
                assert read(short / "verification.json")["status"] == "verified", short
                assert read(root / "verification.json")["status"] == "verified", root
                quality = read(root / "local_quality.json")
                reject, accept = quality["reject"], quality["accept"]
                immediate.append(dict(gamma=gamma(p), seed=seed, parent_block=node,
                                      q_ce_change=accept["q"]["student"]["ce"]-reject["q"]["student"]["ce"],
                                      q_error_change=accept["q"]["student"]["error"]-reject["q"]["student"]["error"],
                                      current_ce_change=accept["current_domain"]["student"]["ce"]-reject["current_domain"]["student"]["ce"],
                                      current_error_change=accept["current_domain"]["student"]["error"]-reject["current_domain"]["student"]["error"]))
                short_comp = {r["h"]: r for r in read(short / "comparison.json")}
                comp = {r["h"]: r for r in read(root / "comparison.json")}
                for h in (94, 1409, 1410):
                    r = short_comp[h] if h == 94 else comp[h]
                    forks.append(dict(gamma=gamma(p), seed=seed, parent_block=node, horizon=h,
                                      reject_closed=r["reject_closed"], reject_replay=r["reject_replay"],
                                      accept_closed=r["accept_closed"], accept_replay=r["accept_replay"],
                                      A_closed=r["A_closed"], A_open=r["A_open"], I_feedback=r["I_feedback"]))

            if not full:
                continue
            trajectory[(p, seed)] = [all_blocks[i]["fixed_q"] for i in range(45)]
            probes = [r for r in all_updates if r.get("local_probe") and r.get("updated") and
                      r.get("proxy_delta") is not None and r.get("local_delta") is not None]
            probe_points[(p, seed)] = [(r["proxy_delta"], r["local_delta"]) for r in probes]
            quadrants = {"both_improve": 0, "proxy_improves_local_worsens": 0,
                         "proxy_worsens_local_improves": 0, "both_worsen": 0, "near_zero": 0}
            for x, y in probe_points[(p, seed)]:
                if abs(x) < 1e-4 or abs(y) < 1e-4:
                    quadrants["near_zero"] += 1
                elif x < 0 and y < 0:
                    quadrants["both_improve"] += 1
                elif x < 0 and y > 0:
                    quadrants["proxy_improves_local_worsens"] += 1
                elif x > 0 and y < 0:
                    quadrants["proxy_worsens_local_improves"] += 1
                else:
                    quadrants["both_worsen"] += 1
            signs.append(dict(gamma=gamma(p), seed=seed, probes=len(probes), **quadrants))
            for r in probes:
                probes_out.append(dict(gamma=gamma(p), seed=seed, block=r["block"], cycle=r["cycle"]+1,
                                       domain=r["domain"], batch=r["batch"], proxy_delta=r["proxy_delta"],
                                       local_ce_delta=r["local_delta"],
                                       local_error_delta=r["local_post"]["error"]-r["local_pre"]["error"]))

            for i in range(45):
                b = all_blocks[i]
                q = b["fixed_q"]
                counts = b["counts_selected"]
                u = updates_by_block[i]
                adapt_conf = sum(r["confidence_mean"]*r["n"] for r in u) / sum(r["n"] for r in u)
                blocks.append(dict(gamma=gamma(p), seed=seed, block=i, cycle=i // 15 + 1,
                                   domain=b["domain"], student_pre_ce=b["pre"]["student"]["ce"],
                                   student_post_ce=b["post"]["student"]["ce"],
                                   student_pre_error=b["pre"]["student"]["error"],
                                   student_post_error=b["post"]["student"]["error"],
                                   teacher_pre_ce=b["pre"]["teacher"]["ce"],
                                   teacher_post_ce=b["post"]["teacher"]["ce"],
                                   teacher_pre_error=b["pre"]["teacher"]["error"],
                                   teacher_post_error=b["post"]["teacher"]["error"],
                                   fixed_q_student_ce=q["student"]["ce"], fixed_q_student_error=q["student"]["error"],
                                   fixed_q_teacher_ce=q["teacher"]["ce"], fixed_q_teacher_error=q["teacher"]["error"],
                                   mixed_target_ce=q["diagnostic_state"][1], js=q["diagnostic_state"][2],
                                   mixed_confidence=q["diagnostic_state"][3], adaptation_confidence_mean=adapt_conf,
                                   pseudo_noise_all=b["wrong_all"] / b["images"],
                                   pseudo_noise_selected=b["wrong_selected"] / b["selected"] if b["selected"] else None,
                                   coverage=b["selected"] / b["images"], concentration=concentration(counts),
                                   disagreement=b["disagreements"] / b["images"],
                                   selected=b["selected"], images=b["images"], wrong_all=b["wrong_all"],
                                   wrong_selected=b["wrong_selected"], disagreements=b["disagreements"],
                                   selected_counts_by_class=json.dumps(counts, separators=(",", ":")),
                                   optimizer_steps=b["optimizer_steps"], empty_masks=b["empty_masks"],
                                   seconds=b["seconds_including_checkpoint"], peak_gpu_bytes=b["peak_gpu_bytes"]))
                xt.append(dict(gamma=gamma(p), seed=seed, block=i, cycle=i // 15 + 1,
                               x1=q["diagnostic_state"][0], x2=q["diagnostic_state"][1],
                               x3=q["diagnostic_state"][2], x4=q["diagnostic_state"][3]))

            for cycle in range(3):
                subset = [all_blocks[i] for i in range(cycle * 15, (cycle + 1) * 15)]
                counts = [sum(b["counts_selected"][j] for b in subset) for j in range(100)]
                selected = sum(b["selected"] for b in subset)
                images = sum(b["images"] for b in subset)
                end = subset[-1]["fixed_q"]
                uu = [u for i in range(cycle * 15, (cycle + 1) * 15) for u in updates_by_block[i]]
                cycles.append(dict(gamma=gamma(p), seed=seed, cycle=cycle + 1,
                                   student_q_ce=end["student"]["ce"], student_q_error=end["student"]["error"],
                                   teacher_q_ce=end["teacher"]["ce"], teacher_q_error=end["teacher"]["error"],
                                   mixed_q_ce=end["diagnostic_state"][1], js=end["diagnostic_state"][2],
                                   mixed_confidence=end["diagnostic_state"][3],
                                   noise_all=sum(b["wrong_all"] for b in subset) / images,
                                   noise_selected=sum(b["wrong_selected"] for b in subset) / selected if selected else None,
                                   coverage=selected / images, concentration=concentration(counts),
                                   adaptation_confidence_mean=sum(u["confidence_mean"]*u["n"] for u in uu) / sum(u["n"] for u in uu),
                                   selected_counts_by_class=json.dumps(counts, separators=(",", ":")),
                                   disagreement=sum(b["disagreements"] for b in subset) / images,
                                   optimizer_steps=sum(b["optimizer_steps"] for b in subset),
                                   empty_masks=sum(b["empty_masks"] for b in subset),
                                   seconds=sum(b["seconds_including_checkpoint"] for b in subset)))

            all_list = [all_blocks[i] for i in range(45)]
            first = all_list[:15]
            final = all_list[30:]
            selected = sum(b["selected"] for b in all_list)
            sweep.append(dict(gamma=gamma(p), seed=seed,
                              mean_post_ce=sum(b["post"]["student"]["ce"] for b in all_list) / 45,
                              mean_post_error=sum(b["post"]["student"]["error"] for b in all_list) / 45,
                              mean_same_domain_ce_change=sum(final[j]["post"]["student"]["ce"] - first[j]["post"]["student"]["ce"] for j in range(15)) / 15,
                              mean_same_domain_error_change=sum(final[j]["post"]["student"]["error"] - first[j]["post"]["student"]["error"] for j in range(15)) / 15,
                              final_cycle_mean_ce=sum(b["post"]["student"]["ce"] for b in final) / 15,
                              final_cycle_mean_error=sum(b["post"]["student"]["error"] for b in final) / 15,
                              coverage=selected / sum(b["images"] for b in all_list),
                              optimizer_steps=sum(b["optimizer_steps"] for b in all_list),
                              empty_masks=sum(b["empty_masks"] for b in all_list),
                              seconds=sum(b["seconds_including_checkpoint"] for b in all_list),
                              peak_gpu_gb=max(b["peak_gpu_bytes"] for b in all_list) / 1e9))

            for node in (5, 15):
                a = read(dpath / f"dynamics_b{node}/dynamics_analysis.json")
                resp = read(dpath / f"dynamics_b{node}/responses.json")
                x0 = next(r["x0"] for r in resp if r["obj"] == "base")
                fit1 = a["fits"].get("0.0001")
                fit3 = a["fits"].get("0.0003")
                gg = [g["gain"] for g in a["gains"] if g["gain"] is not None]
                assert a["finite_responses"] == 132 and a["total_responses"] == 132
                if fit1:
                    assert fit3 and fit1["closure_falsified"] and fit3["closure_falsified"]
                else:
                    assert not fit3 and not gg and not all(a["coordinate_resolved"])
                dynamics.append(dict(gamma=gamma(p), seed=seed, parent_block=node,
                                     x0=x0, F=a["F_at_parent"], F_tape_sd=a["F_tape_sd"],
                                     finite_responses=a["finite_responses"], median_G=statistics.median(gg) if gg else None,
                                     G_min=min(gg) if gg else None, G_max=max(gg) if gg else None,
                                     W=a.get("W_diagonal"), coordinate_resolved=a["coordinate_resolved"],
                                     rank_small=fit1["rank"] if fit1 else None,
                                     rank_large=fit3["rank"] if fit3 else None,
                                     condition_small=fit1["condition"] if fit1 else None,
                                     condition_large=fit3["condition"] if fit3 else None,
                                     scale_difference=a.get("relative_scale_difference"),
                                     heldout_median_small=statistics.median(fit1["validation_residuals"]) if fit1 else None,
                                     heldout_median_large=statistics.median(fit3["validation_residuals"]) if fit3 else None,
                                     identity_median=statistics.median(fit1["identity_residuals"]) if fit1 else None,
                                     no_response_median=statistics.median(fit1["no_response_residuals"]) if fit1 else None,
                                     label_switches=sum(h["label_switches"] for h in a["hard_switches"]),
                                     mask_switches=sum(h["mask_switches"] for h in a["hard_switches"]),
                                     closure_falsified=True if fit1 else None, J_identified=False,
                                     spectrum_usable=False, reason=a.get("reason", "projection not closed")))

    assert len(coverage) == 18 and len(signs) == 12 and len(cycles) == 36
    assert len(blocks) == 540 and len(sweep) == 12 and len(forks) == 72 and len(dynamics) == 24
    assert len(xt) == 540 and len(failure_rows) == 6
    assert len(probes_out) == 1080 and len(immediate) == 24
    return dict(coverage=coverage, signs=signs, cycles=cycles, blocks=blocks, sweep=sweep,
                forks=forks, dynamics=dynamics, xt=xt, failures=failure_rows,
                probes=probes_out, immediate=immediate, probe_points=probe_points, trajectory=trajectory)


INK = colors.HexColor("#14283B")
BLUE = colors.HexColor("#2066A3")
ORANGE = colors.HexColor("#D7833C")
PALE = colors.HexColor("#EAF0F6")
GRAY = colors.HexColor("#657688")


def p(text, style):
    return Paragraph(escape(str(text)), style)


def table(data, widths, font=7.0, row_h=None, header=True, bg=None, pad=1.7):
    if row_h is None:
        row_h = font + 2 * pad + 1.0
    t = Table(data, colWidths=widths, rowHeights=row_h, repeatRows=1 if header else 0, hAlign="LEFT")
    cmds = [
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), font),
        ("TEXTCOLOR", (0, 0), (-1, -1), INK),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), pad),
        ("BOTTOMPADDING", (0, 0), (-1, -1), pad),
        ("LEFTPADDING", (0, 0), (-1, -1), 4),
        ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ("LINEBELOW", (0, 0), (-1, 0), .8, BLUE),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F6F8FA")]),
    ]
    if bg:
        cmds.extend(bg)
    t.setStyle(TableStyle(cmds))
    return t


def line_panel(d, values, title, x, y, w, h):
    d.add(String(x + 3, y + h - 13, title, fontSize=8, fontName="Helvetica-Bold", fillColor=INK))
    px, py, pw, ph = x + 26, y + 18, w - 36, h - 38
    all_y = [z for series in values for z in series]
    ymin, ymax = min(all_y + [SOURCE_CE]), max(all_y + [SOURCE_CE])
    pad = max(.05, (ymax - ymin) * .08)
    ymin -= pad
    ymax += pad
    d.add(Line(px, py, px, py + ph, strokeColor=GRAY, strokeWidth=.5))
    d.add(Line(px, py, px + pw, py, strokeColor=GRAY, strokeWidth=.5))
    for cut in (14.5, 29.5):
        xx = px + pw * cut / 44
        d.add(Line(xx, py, xx, py + ph, strokeColor=colors.HexColor("#CED7E0"), strokeWidth=.5))
    sy = py + ph * (SOURCE_CE - ymin) / (ymax - ymin)
    d.add(Line(px, sy, px + pw, sy, strokeColor=GRAY, strokeWidth=.5, strokeDashArray=[2, 2]))
    for series, col in zip(values, (BLUE, ORANGE)):
        coords = []
        for i, v in enumerate(series):
            coords += [px + pw * i / 44, py + ph * (v - ymin) / (ymax - ymin)]
        d.add(PolyLine(coords, strokeColor=col, strokeWidth=1.15))


def trajectory_drawing(data, keys):
    d = Drawing(760, 216)
    for idx, (point, seed) in enumerate(keys):
        trace = data["trajectory"][(point, seed)]
        col, row = idx % 3, idx // 3
        vals = [[r["student"]["ce"] for r in trace], [r["teacher"]["ce"] for r in trace]]
        line_panel(d, vals, label(point, seed), col * 250, 108 * (1 - row), 246, 105)
    d.add(String(5, 3, "Blue: student fixed-Q CE  |  orange: EMA teacher CE  |  dashed: source CE", fontSize=7, fillColor=GRAY))
    return d


def scatter_drawing(data, keys):
    d = Drawing(760, 260)
    for idx, (point, seed) in enumerate(keys):
        pts = data["probe_points"][(point, seed)]
        col, row = idx % 3, idx // 3
        x, y, w, h = col * 250, 130 * (1 - row), 246, 126
        d.add(String(x + 3, y + h - 13, label(point, seed), fontSize=8, fontName="Helvetica-Bold", fillColor=INK))
        px, py, pw, ph = x + 26, y + 18, w - 36, h - 38
        mx = max(abs(v[0]) for v in pts) * 1.05 or 1
        my = max(abs(v[1]) for v in pts) * 1.05 or 1
        d.add(Line(px, py + ph / 2, px + pw, py + ph / 2, strokeColor=GRAY, strokeWidth=.5))
        d.add(Line(px + pw / 2, py, px + pw / 2, py + ph, strokeColor=GRAY, strokeWidth=.5))
        for xx, yy in pts:
            cx = px + pw * (.5 + .5 * xx / mx)
            cy = py + ph * (.5 + .5 * yy / my)
            d.add(Circle(cx, cy, 1.25, strokeColor=None, fillColor=ORANGE if xx < 0 < yy else BLUE))
        d.add(String(px, y + 4, "proxy change (x); local probe change (y)", fontSize=6, fillColor=GRAY))
    return d


def process_drawing(data, metric, title):
    """Show each exploratory seed separately at every block for the four viable gamma points."""
    d = Drawing(760, 424)
    palette = (BLUE, ORANGE, colors.HexColor("#388C77"))
    for idx, point in enumerate((0, 2, 4, 5)):
        col, row = idx % 2, idx // 2
        x, y, w, h = col * 380, (1 - row) * 210, 374, 204
        d.add(String(x + 5, y + h - 12, f"gamma = {gamma(point)}", fontSize=8,
                     fontName="Helvetica-Bold", fillColor=INK))
        px, py, pw, ph = x + 35, y + 24, w - 46, h - 51
        series = []
        for seed in (202, 303, 404):
            rows = sorted((r for r in data["blocks"] if r["gamma"] == gamma(point)
                           and r["seed"] == seed), key=lambda r: r["block"])
            assert len(rows) == 45
            series.append([r[metric] for r in rows])
        finite = [v for values in series for v in values if v is not None]
        assert finite, (metric, point)
        ymin, ymax = min(finite), max(finite)
        padding = max(.005, (ymax - ymin) * .07)
        ymin, ymax = max(0, ymin - padding), min(1, ymax + padding)
        d.add(Line(px, py, px, py + ph, strokeColor=GRAY, strokeWidth=.5))
        d.add(Line(px, py, px + pw, py, strokeColor=GRAY, strokeWidth=.5))
        d.add(String(px - 32, py - 2, f"{100*ymin:.1f}", fontSize=6, fillColor=GRAY))
        d.add(String(px - 32, py + ph - 2, f"{100*ymax:.1f}", fontSize=6, fillColor=GRAY))
        for boundary in (14.5, 29.5):
            xx = px + pw * boundary / 44
            d.add(Line(xx, py, xx, py + ph, strokeColor=colors.HexColor("#CED7E0"),
                       strokeWidth=.5, strokeDashArray=[2, 2]))
        for seed, values, color in zip((202, 303, 404), series, palette):
            segment = []
            for block, value in enumerate(values):
                if value is None:
                    if len(segment) >= 4:
                        d.add(PolyLine(segment, strokeColor=color, strokeWidth=1.05))
                    segment = []
                    continue
                segment.extend([px + pw * block / 44, py + ph * (value - ymin) / (ymax - ymin)])
            if len(segment) >= 4:
                d.add(PolyLine(segment, strokeColor=color, strokeWidth=1.05))
        d.add(String(px, y + 7, "block 0", fontSize=6, fillColor=GRAY))
        d.add(String(px + pw - 27, y + 7, "44", fontSize=6, fillColor=GRAY))
    return d


def build_pdf(data):
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="T", parent=styles["Title"], fontName="Helvetica-Bold", fontSize=17,
                              leading=20, textColor=INK, spaceAfter=10, alignment=TA_CENTER))
    styles.add(ParagraphStyle(name="H", parent=styles["Heading2"], fontName="Helvetica-Bold", fontSize=11,
                              leading=13, textColor=BLUE, spaceBefore=10, spaceAfter=6))
    styles.add(ParagraphStyle(name="B", parent=styles["BodyText"], fontName="Helvetica", fontSize=8.2,
                              leading=11, textColor=INK, spaceAfter=5))
    styles.add(ParagraphStyle(name="S", parent=styles["BodyText"], fontName="Helvetica", fontSize=7,
                              leading=9, textColor=GRAY, spaceAfter=5))
    doc = SimpleDocTemplate(str(PDF), pagesize=landscape(A4), leftMargin=34, rightMargin=34,
                            topMargin=35, bottomMargin=32, title="C4 Full Exploratory Results",
                            author="RSD C4 experiment team")
    W = landscape(A4)[0] - 68
    story = []
    def H(s): story.append(p(s, styles["H"]))
    def B(s): story.append(p(s, styles["B"]))
    def S(s): story.append(p(s, styles["S"]))
    def T(rows, widths, font=7, bg=None, pad=1.7): story.append(table(rows, widths, font=font, bg=bg, pad=pad))
    def page(): story.append(PageBreak())

    story.append(p("C4: Full Exploratory Grid and Dynamics Results", styles["T"]))
    B(f"Evidence cutoff: {CUTOFF}. All 12 viable gamma-by-seed cells have verified three-cycle and H20 results. Six high-beta teacher-weighted parent runs terminated numerically and have unavailable downstream components. All 12 viable cells also have verified one-cycle forks. This report uses only completed components.")
    B("Scientific boundary: these are exploratory runs on a fixed CIFAR-100-C severity-5 setting and exploratory audit. Seed 101 is a separate discovery case. A positive endpoint contrast is not a persistent deterioration trend; nonfinite arithmetic is not recursive behavioral decline. The four-coordinate diagnostic is not a closed state model in the completed perturbation tests.")
    H("Complete gamma x seed status")
    rows = [["gamma=(lambda,beta)", "seed", "one-cycle parent", "H94/H1410 forks", "three cycles", "H20 / J"]]
    for c in data["coverage"]:
        rows.append([c["gamma"], str(c["seed"]), c["parent"], c["forks"], c["three_cycle"], c["H20_J"]])
    T(rows, [115, 42, 174, 120, 126, W - 577], font=7.2)
    S("The six numerical failures are lambda=1 or 0.5 with beta=.01 at every seed. Their first-cycle parent stopped with nonfinite post-update loss; downstream fork, extension and H20 values are unavailable. No result is imputed for those cells.")

    page()
    H("C4-1. Proxy change versus labelled local probe")
    B("Each point is a first/last scheduled minibatch probe within a completed block. Both changes are post minus pre cross-entropy; negative means a measured improvement. Near zero means either absolute change < 1e-4. These are finite exploratory-audit signs, not population guarantees. Natural C4 has no accept/reject evaluator gate.")
    proxy_improvements = sum(r["proxy_delta"] < 0 for r in data["probes"])
    local_worsenings = sum(r["local_ce_delta"] > 0 for r in data["probes"])
    B(f"Across the 12 complete cells, proxy CE decreases in {proxy_improvements}/{len(data['probes'])} scheduled probes, while labelled local CE increases in {local_worsenings}/{len(data['probes'])}. This is a measured proxy/local mismatch, not a claim that an evaluator accepted a harmful update.")
    rows = [["gamma", "seed", "probes", "both improve", "proxy improves; local worsens", "proxy worsens; local improves", "both worsen", "near zero"]]
    for r in data["signs"]:
        rows.append([r["gamma"], str(r["seed"]), str(r["probes"]), str(r["both_improve"]),
                     str(r["proxy_improves_local_worsens"]), str(r["proxy_worsens_local_improves"]),
                     str(r["both_worsen"]), str(r["near_zero"])])
    T(rows, [90, 43, 51, 75, 155, 153, 87, W - 654], font=6.8)
    keys = sorted(data["trajectory"])
    story.append(Spacer(1, 10))
    story.append(scatter_drawing(data, keys[:6]))
    page()
    H("C4-1. Remaining completed cells")
    story.append(scatter_drawing(data, keys[6:]))
    S("All 12 viable cells are plotted, six on each page. Failed parents have no three-cycle probes. Full probe-level records remain in parent/extension updates.jsonl.")

    page()
    H("C4-2. Fixed-Q learner and teacher trajectories")
    B("The fixed Q panel has 100 base images under all 15 corruptions (1,500 image-corruption evaluations). Curves show every completed block, without smoothing; student and teacher are separate. Source CE is 2.45255 and source error is 45.47%. The three-cycle directions are mixed, not monotonic decline.")
    story.append(trajectory_drawing(data, keys[:6]))
    page()
    H("C4-2. Remaining fixed-Q trajectories")
    story.append(trajectory_drawing(data, keys[6:]))
    page()
    H("C4-2. Cycle-end fixed-Q measurements")
    rows = [["gamma", "seed", "cycle", "student CE", "student err %", "teacher CE", "teacher err %", "mix CE", "JS", "max-conf"]]
    for r in data["cycles"]:
        rows.append([r["gamma"], str(r["seed"]), str(r["cycle"]), fmt(r["student_q_ce"]),
                     fmt(100*r["student_q_error"],1), fmt(r["teacher_q_ce"]), fmt(100*r["teacher_q_error"],1),
                     fmt(r["mixed_q_ce"]), fmt(r["js"],4), fmt(r["mixed_confidence"],4)])
    T(rows, [80, 37, 39, 76, 80, 76, 80, 76, 70, W-614], font=6.8)

    page()
    H("C4-2. Pseudo-supervision, selection and cost by cycle")
    B("Noise and disagreement are count-weighted over adaptation images; selected-label noise is undefined if selection is empty. Concentration is 1 - selected-label entropy/log(100), pooled within each cycle. It measures concentration, not harm by itself. Empty masks and actual optimizer steps are logged separately. Companion cycle/block CSVs retain adaptation-stream mean confidence and all 100 selected-class counts.")
    rows = [["gamma", "seed", "cycle", "noise all %", "noise sel %", "coverage %", "concentration", "disagree %", "steps", "empty", "seconds"]]
    for r in data["cycles"]:
        rows.append([r["gamma"], str(r["seed"]), str(r["cycle"]), fmt(100*r["noise_all"],1),
                     fmt(100*r["noise_selected"],1) if r["noise_selected"] is not None else "undef.",
                     fmt(100*r["coverage"],1), fmt(r["concentration"],3),
                     fmt(100*r["disagreement"],1), str(r["optimizer_steps"]), str(r["empty_masks"]), fmt(r["seconds"],0)])
    T(rows, [77, 37, 36, 73, 73, 72, 92, 75, 49, 43, W-627], font=6.8)
    for metric, title in (("pseudo_noise_selected", "Selected pseudo-label noise"),
                          ("coverage", "Selection coverage"),
                          ("concentration", "Selected-class concentration"),
                          ("disagreement", "Student/teacher disagreement")):
        page()
        H(f"C4-2. Block-level {title.lower()}")
        B("Each line is one exploratory seed across 45 completed blocks (blue: 202; orange: 303; green: 404); dashed boundaries separate the three corruption cycles. The vertical axis is percent. Values use the scheduled adaptation stream, not fixed Q. The table and CSV retain cycle aggregation and counts. No smoothing or seed selection is applied.")
        story.append(process_drawing(data, metric, title))

    page()
    H("C4-3. Same-domain returns across visits")
    B("The heatmap is the student current-domain post-block CE on visit 3 minus visit 1 for the identical corruption and audit IDs. Positive is worse. The complete appendix gives student and teacher pre/post CE and error for all 15 corruptions at all three visits, including the unselected adverse and beneficial domains.")
    names = [r["domain"] for r in data["blocks"] if r["gamma"] == gamma(keys[0][0]) and r["seed"] == keys[0][1] and r["cycle"] == 1]
    for group in (keys[:6], keys[6:]):
        rows = [["corruption"] + [label(*key) for key in group]]
        bg = []
        for j, name in enumerate(names):
            rr = [name]
            for i, key in enumerate(group):
                pnt, seed = key
                bs = [r for r in data["blocks"] if r["gamma"] == gamma(pnt) and r["seed"] == seed]
                delta = bs[30+j]["student_post_ce"] - bs[j]["student_post_ce"]
                rr.append(f"{delta:+.3f}")
                if delta > .02: color = colors.HexColor("#F8DCD8")
                elif delta < -.02: color = colors.HexColor("#DCEBF8")
                else: color = colors.HexColor("#EEF0F1")
                bg.append(("BACKGROUND", (i+1,j+1), (i+1,j+1), color))
            rows.append(rr)
        T(rows, [145] + [(W-145)/6]*6, font=7.1, bg=bg)
        story.append(Spacer(1, 8))
    S("Blue: lower CE on the third visit; red: higher CE; gray: change within +/-0.02. Current-domain CE can change because of adaptation and return-domain difficulty; the fixed-Q series above is the common-reference check.")

    page()
    H("C4-4. Per-cell parameter sweep summary")
    B("All averages below are descriptive over 45 blocks, not uncertainty intervals. Same-domain change compares visit 3 with visit 1. Cost is the summed measured block time including checkpoints; it excludes separate fork and H20 cost.")
    rows = [["gamma", "seed", "mean post CE", "mean post err %", "return dCE", "return derr pp", "cycle-3 CE", "cycle-3 err %", "coverage %", "updates", "cost min"]]
    for r in data["sweep"]:
        rows.append([r["gamma"], str(r["seed"]), fmt(r["mean_post_ce"]), fmt(100*r["mean_post_error"],1),
                     f"{r['mean_same_domain_ce_change']:+.3f}", f"{100*r['mean_same_domain_error_change']:+.2f}",
                     fmt(r["final_cycle_mean_ce"]), fmt(100*r["final_cycle_mean_error"],1),
                     fmt(100*r["coverage"],1), str(r["optimizer_steps"]), fmt(r["seconds"]/60,1)])
    T(rows, [78, 38, 73, 78, 69, 78, 74, 78, 68, 54, W-688], font=6.8)
    S(f"Mean same-domain error change is negative in {sum(r['mean_same_domain_error_change'] < 0 for r in data['sweep'])} of 12 viable cells; mean CE change is positive in {sum(r['mean_same_domain_ce_change'] > 0 for r in data['sweep'])}. Loss and classification error must stay separate.")

    page()
    H("C4-5. Matched accept/reject and closed/replay contrasts")
    B("All 12 viable one-cycle cells have verified preselected block-5 and block-15 forks, including seed 404. The four Q risks are reported at H94, H1409 and H1410 on the following pages. A_closed = accept_closed - reject_closed; A_open = accept_replay - reject_replay; I_feedback = A_closed - A_open. Positive is worse. A positive I alone does not show absolute deterioration.")
    h1410 = [r for r in data["forks"] if r["horizon"] == 1410]
    n_harmful_closed = sum(r["A_closed"] > 0 for r in h1410)
    n_positive_feedback = sum(r["I_feedback"] > 0 for r in h1410)
    B(f"At H1410, {n_harmful_closed} of the {len(h1410)} correlated parent-by-cell nodes have A_closed > 0 and {n_positive_feedback} have I_feedback > 0. For lambda=0, I_feedback is exactly zero in this archive. These are descriptive node counts, not independent-seed event probabilities.")
    B("The two short/long fork runs share their first 94 steps, so H94 is a common prefix, not a second independent replicate. H1409 ends an exact 15-domain continuation; H1410 includes the next update. Student classification error is distinct from these CE contrasts. Full branch curves and error endpoints remain in the verified fork evidence.")
    H("Immediate focal-candidate changes (accept minus reject)")
    B("Each focal proposal is the first nonempty update after its preselected parent block, regardless of sign. Positive means worse on the finite audit. Natural C4 executes the update without an evaluator acceptance gate; these are measurements, not pass/fail decisions.")
    rows = [["gamma", "seed", "parent", "fixed-Q dCE", "fixed-Q dErr pp", "current-domain dCE", "current-domain dErr pp"]]
    for r in data["immediate"]:
        rows.append([r["gamma"], str(r["seed"]), str(r["parent_block"]),
                     f"{r['q_ce_change']:+.3f}", f"{100*r['q_error_change']:+.2f}",
                     f"{r['current_ce_change']:+.3f}", f"{100*r['current_error_change']:+.2f}"])
    T(rows, [87, 42, 47, 125, 132, 157, W-590], font=6.8)
    page()
    for h in (94, 1409, 1410):
        H(f"C4-5: horizon H{h} (fixed-Q CE; positive contrast = worse)")
        rows = [["gamma", "seed", "parent", "R closed", "R replay", "A closed", "A replay", "A_closed", "A_open", "I_feedback"]]
        for r in data["forks"]:
            if r["horizon"] != h: continue
            rows.append([r["gamma"], str(r["seed"]), str(r["parent_block"]),
                         fmt(r["reject_closed"]), fmt(r["reject_replay"]), fmt(r["accept_closed"]),
                         fmt(r["accept_replay"]), f"{r['A_closed']:+.3f}", f"{r['A_open']:+.3f}",
                         f"{r['I_feedback']:+.3f}"])
        T(rows, [75, 39, 43, 81, 81, 81, 81, 81, 81, W-642], font=6.8)
        if h != 1410: page()

    page()
    H("C4-6. H20 finite response and state-map checks")
    B("At every completed block, x_t = (student fixed-Q CE, mixed-target fixed-Q CE, student/teacher JS, mean maximum mixed-target confidence). The companion x_t CSV contains all 540 block states. This diagnostic trajectory is not by itself a closed recursive state law.")
    B("For each viable cell, both fixed parent phases use 132 finite H20 continuations: independent student/teacher directions at two amplitudes, three training tapes and held-out validation tapes. F at the parent is the mean future x over three base tapes, conditioned on phase, gamma and this intervention design. It is a measured conditional response, not a universal transition function.")
    rows = [["gamma", "seed", "parent", "x0 = (risk, mix, JS, conf)", "F_H20(x0) = (risk, mix, JS, conf)", "F tape SD"]]
    for r in data["dynamics"]:
        vec = lambda v: " / ".join(fmt(q,3) for q in v)
        rows.append([r["gamma"], str(r["seed"]), str(r["parent_block"]),
                     vec(r["x0"]), vec(r["F"]), vec(r["F_tape_sd"])])
    T(rows, [80, 39, 43, 197, 197, W-556], font=6.6)
    page()
    H("Identifiability summary")
    B("At lambda=1 or 0.5, 12 completed parent phases have rank-4 local input designs, but scale sensitivity and/or held-out prediction fail; momentum-only changes leave initial x unchanged and produce resolved future differences, falsifying closure. At lambda=0, the mixed-target CE and confidence coordinates are fixed, so two coordinate scales are zero and neither standardized G nor a four-dimensional fit is defined. No candidate matrix is interpreted as a system Jacobian, contraction test, or phase boundary.")
    rows = [["gamma", "seed", "parent", "finite", "median G", "rank", "cond .0001 / .0003", "scale d", "holdout med .0001 / .0003", "identity / no-resp", "label / mask switches"]]
    for r in data["dynamics"]:
        rows.append([r["gamma"], str(r["seed"]), str(r["parent_block"]), str(r["finite_responses"]),
                     fmt(r["median_G"],1), f"{r['rank_small']}/{r['rank_large']}" if r["rank_small"] is not None else "not fit",
                     f"{r['condition_small']:.1f}/{r['condition_large']:.1f}" if r["condition_small"] is not None else "not fit",
                     fmt(r["scale_difference"],2),
                     f"{r['heldout_median_small']:.1f}/{r['heldout_median_large']:.1f}" if r["heldout_median_small"] is not None else "not fit",
                     f"{r['identity_median']:.1f}/{r['no_response_median']:.1f}" if r["identity_median"] is not None else "not fit",
                     f"{r['label_switches']}/{r['mask_switches']}"])
    T(rows, [72, 36, 38, 42, 55, 40, 108, 56, 128, 94, W-669], font=6.5)
    S("G is standardized future separation divided by standardized initial separation; large gains can reflect tiny initial projected changes. W is frozen from training-perturbation RMS and stored per parent in the companion C4-6 CSV. Prediction residuals use held-out direction families. No rho(J) is reported because the closure/holdout conditions fail and no repeatable fixed point has been shown.")

    page()
    H("C4-7. What the present parameter map does and does not show")
    B("This 3 x 2 vector-gamma map contains six distinct parameter points and three reused exploratory seeds per point. Two beta=.01 teacher-weighted points are numerical failures for all seeds. At the remaining four points, one-cycle fork signs vary with seed, parent and horizon; all 12 viable three-cycle trajectories and local responses are retained without outcome selection. The lambda=0 rows are anchored adaptation, not frozen learning. The present evidence does not identify a phase boundary or robust persistent self-deterioration regime.")
    H("Terminated numerical failures")
    B("The learner raised a nonfinite post-update loss before a usable block-5 checkpoint. The table counts fully completed blocks before termination; partial failing-block updates remain in the remote raw log. No downstream value is imputed.")
    rows = [["gamma", "seed", "completed blocks", "downstream status"]]
    rows.extend([[r["gamma"], str(r["seed"]), str(r["completed_blocks"]), "fork / 3-cycle / H20 unavailable"] for r in data["failures"]])
    T(rows, [105, 45, 115, W-265], font=7)
    H("Coverage and interpretation ledger")
    rows = [["C4 item", "Completed evidence in this PDF", "Missing at cutoff"]]
    ledger = [
        ("C4-1 local signs", "12 full cells, all scheduled probes; scatter and sign counts", "6 failed parents have no three-cycle probes"),
        ("C4-2 trajectories", "12 x 45 block Q and domain records; source, student, teacher, pseudo-process", "6 failed parents unavailable"),
        ("C4-3 returns", "all 15 domains x 3 visits for 12 cells; exact pre/post appendix", "6 failed parents have no complete visits"),
        ("C4-4 sweep", "12 per-cell risk, coverage, update and cost summaries", "6 failed parents excluded from finite summaries"),
        ("C4-5 forks", "12 viable cells x 2 parents x 3 horizons; all four risks and contrasts", "6 failed parents have no focal checkpoint"),
        ("C4-6 dynamics", "12 cells x 2 parents: x, F, finite G, rank/condition, scale, holdout, closure", "6 failed parents unavailable; J and spectrum not justified"),
        ("C4-7 regions", "descriptive status/sign map", "replicated, identifiable boundary absent"),
    ]
    rows.extend([list(x) for x in ledger])
    T(rows, [112, 315, W-427], font=7)
    H("Decision after this exploratory matrix")
    B("Stop expanding the present gamma sweep: the viable trajectories and matched branches have mixed signs, while the proposed four-coordinate state does not close. If the project continues, specify one feedback intervention and a longer matched horizon at a viable gamma before using independent seeds; retain the untouched confirmation panel for that fixed test. This is a proposed next experiment, not a completed result.")
    B("Data provenance: local compact evidence in this project's Seed_Replication, Parameter_Grid and Dynamics_Completion experiment folders; canonical bulk raw evidence on Sapelo under /scratch/yz54720/RSI2RSD/C4/. Arrays 48452662 and 48452757 supplied the three-cycle/H20 supplement. The reserved gate and untouched confirmation audit were not used as report outcomes. All companion CSVs in Final_2026-09-22 are generated from the same checked inputs as this PDF.")

    for point, seed in sorted(data["trajectory"]):
        page()
        H(f"Appendix: all domain visits, {label(point, seed)}")
        B("Current-domain exploratory audit. CE and classification error are shown pre/post each block for student and teacher. Errors are percentages. Each of the 15 corruptions appears once per cycle; no rows are selected by outcome.")
        bs = [r for r in data["blocks"] if r["gamma"] == gamma(point) and r["seed"] == seed]
        rows = [["visit", "corruption", "S CE pre", "S CE post", "S err pre", "S err post", "T CE pre", "T CE post", "T err pre", "T err post"]]
        for r in bs:
            rows.append([str(r["cycle"]), r["domain"], fmt(r["student_pre_ce"],2), fmt(r["student_post_ce"],2),
                         fmt(100*r["student_pre_error"],1), fmt(100*r["student_post_error"],1),
                         fmt(r["teacher_pre_ce"],2), fmt(r["teacher_post_ce"],2),
                         fmt(100*r["teacher_pre_error"],1), fmt(100*r["teacher_post_error"],1)])
        T(rows, [32, 132] + [(W-164)/8]*8, font=6.25, pad=1.15)

    def footer(canvas, doc):
        canvas.saveState()
        canvas.setStrokeColor(colors.HexColor("#CDD7E0"))
        canvas.line(34, 26, landscape(A4)[0]-34, 26)
        canvas.setFont("Helvetica", 7)
        canvas.setFillColor(GRAY)
        canvas.drawString(34, 16, f"C4 exploratory full grid | {CUTOFF} | completed components only")
        canvas.drawRightString(landscape(A4)[0]-34, 16, f"Page {doc.page}")
        canvas.restoreState()
    doc.build(story, onFirstPage=footer, onLaterPages=footer)


def main():
    data = collect()
    for name in ("coverage", "signs", "cycles", "blocks", "sweep", "forks", "dynamics", "xt", "failures", "probes", "immediate"):
        rows = data[name]
        if name == "dynamics":
            rows = [{k: json.dumps(v) if isinstance(v, list) else v for k, v in r.items()} for r in rows]
        write_csv(f"C4_{name}.csv", rows)
    build_pdf(data)
    print(json.dumps({"pdf": str(PDF), "bytes": PDF.stat().st_size,
                      "counts": {k: len(data[k]) for k in ("coverage", "signs", "cycles", "blocks", "sweep", "forks", "dynamics", "xt", "failures", "probes", "immediate")}}, indent=2))


if __name__ == "__main__":
    main()
