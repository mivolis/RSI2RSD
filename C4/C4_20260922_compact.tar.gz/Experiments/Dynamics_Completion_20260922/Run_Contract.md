# C4 complete-output supplement — authorized2026-09-22

## Scope
User requests every C4 quantity for every current gamma × seed. Matrix: lambda0/.5/1 × beta.001/.01 × seeds202/303/404 =18cells. Seed101 remains separate discovery evidence, not a new replication. No new confirmation seeds or confirmation-audit access. Optional label-gated algorithm is not part of the natural learner output contract.

## Outputs and coverage
Each of18cells receives explicit coverage for C4-1 local proxy versus labelled probes; C4-2 student/teacher error/CE, fixed-Q risks, pseudo-noise, coverage/concentration/disagreement; C4-3 same-domain returns across3cycles; C4-4 parameter summaries, effective updates/runtime; C4-5 existing fixed block5/15 H94/H1410 forks and H1409 contrasts; C4-6 four-coordinate x, empirical conditional-mean response at parent, finite gains, local-map rank/conditioning/scale sensitivity, held-out predictions, momentum closure and hard mask/label switches; C4-7 descriptive parameter table with unclassified cells. J and spectrum only when identification checks permit; no forced phase regions or stability certificate.

Preserve all finite and failed cells. Parent checkpoints missing due numerical failure are unavailable, not zero. Continue usable earlier fixed parents even if a later trajectory failed. No rerun to change failed outcomes. Numerical failure is not scientific deterioration. Three seed averages do not establish a broad phase map.

## Reuse and trajectory extension
Reuse1cycle parents and existing fork evidence. Versioned extend_trajectory.py restores the exact block15 checkpoint, verifies its hash, and continues blocks15–44 using the unchanged learner, audit and update code. No repeated first cycle. Store parent provenance and extension separately; concatenate only in analysis. Failed parents without block15 receive unavailable extension status.

## Dynamics design, frozen before results
For each available block5/15 parent: H20; four student and four teacher layer-normalized directions; symmetric signs at1e-4/3e-4;3paired tapes91001/2/3.99training continuations per parent. Validation:4mixed directions with symmetric signs and3independent tapes92001/2/3, plus base and symmetric momentum-only direction:33continuations. Total132 per parent,264 per complete cell;4752maximum across18cells before missing parents. Save initial/full final states, logits, schedule keys, all20raw steps and failure traces.

W is inverse coordinate RMS from training perturbations only, frozen before validation. Unresolved/zero scales => no four-dimensional gain/J. Full rank and standardized condition<=1000 required. Scale-relative matrix difference<=.25 is a declared exploratory screen. Held-out projected prediction must outperform both identity/no-response baselines; report residuals, not just pass/fail. Momentum-only unchanged initial x with resolved future x falsifies closure. Candidate fits remain explicitly exploratory; no fixed-point evidence means spectrum cannot certify stability even if identified. Uncertainty is limited by3tapes; cross-seed results remain separate.

## Execution and safety
Remote root /scratch/yz54720/RSI2RSD/C4/dynamics_v1; code_id rsd_c4.dynamics.v1. Original c4.py/forks.py unchanged. Sapelo is code/raw source of truth; local Code/ contains transfer snapshots. At most3GPU total, no paid instances.

Smoke48445882 COMPLETED0:0 in33s on2026-09-22. All three short GPU responses finite; output status complete. Core equality/intervention checks and synthetic full-rank/rank-failure checks passed. This is a functional smoke, not a full-cell timing measurement.

Full study submitted after smoke: first array48452662 indices0–11%3 for all six points seeds202/303; second array48452757 indices12–17%3 for404 dependent afterany:48452662. Both use zhai_p, xz2lab, oneGPU/task,4CPUs/24GB,4h walltime/task; no duplicate submissions. Initial three tasks running on rb7-1 at16:41 EDT. Public dry runs predicted Sept24, zhai immediate. The4h limit is a safe cap, not an ETA. Task mapping and source parents in run_cell.py. Keep archived numerical failures, distinguish supervisor exit from all-component success. verify_cell.py checks present manifests; missing/error components still require coverage review. Scripts syntax-compiled only so far; scientific launch remains test-gated.

## Delivery
English report+PDF with complete18cell output coverage matrix, individual curves/tables and identified/missing reasons. Stage202/303 first,404 last. Compact evidence/config/code/manifests via xfer; raw checkpoints/step files stay remotely indexed. GitHub mivolis/RSI2RSD experiment/C4 under C4/ only. Finish previous pending grid and baseline publications; do not reupload original pilot releases. All exact jobs/logs/verification must be recorded before declaring completion.

## Reporting gate clarified by user, 2026-09-22
Report each result family as soon as that family's computation and evidence check are complete. A gamma×seed three-cycle trajectory is reportable once the parent first cycle and blocks15–44 extension are complete and verified, even if its H20 perturbation/J analysis is still running or has not started. H20/J-specific numbers require their own finished, verified component; do not include provisional diagnostics from a running perturbation. A numerical failure is reportable after termination, with the last valid checkpoint and missing later quantities explicitly marked. The final cross-cell synthesis/PDF still waits for the whole authorized matrix and coverage review. Keep the original raw outputs and failure traces.
