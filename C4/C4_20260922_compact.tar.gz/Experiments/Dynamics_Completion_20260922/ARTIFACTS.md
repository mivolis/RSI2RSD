# C4 dynamics supplement: artifact index

## Complete matrix, verified 2026-09-22 20:56 EDT

- [32-page English full report](C4_Results_Full_2026-09-22_EN.pdf): all 18 gamma-by-seed statuses; 12 verified three-cycle/H20 cells and six terminated numerical failures; C4-1 through C4-7, including every same-domain visit. The report was rendered and inspected after its final build. The previous 18:28 and 20:10 PDFs remain dated snapshots and have not been overwritten.
- [Final tables and SHA256 manifest](Final_2026-09-22/MANIFEST.json): 11 CSVs covering 18 statuses, 1,080 probes, 540 blocks and `x_t` states, 36 cycle ends, 24 parent-phase H20 responses, 72 fork-horizon contrasts, 24 immediate effects, 12 per-cell summaries and six failures. The manifest records PDF, builder and table hashes, row counts and text/visual checks. [Source collector](build_final_report.py) asserts complete coverage before export.
- [Final seed-404 verification](Evidence/VERIFY_FINAL_20260922.json): all four viable seed-404 cells have Slurm `COMPLETED 0:0`, six zero component exits, 32 remote manifests / 10,426 remote checked files per cell, 856 locally mirrored manifest members rehashed, 30 extension blocks, 2,820 extension updates, and two finite H20 phases. The last task was `48452757_17`; all scheduled dynamics tasks are terminal. Failed cells and earlier verified 202/303 cells retain the stage-specific records below.
- Interpretation: finite empirical `F_gamma` at 24 parent phases, but no defensible four-coordinate system Jacobian, spectrum or phase boundary. Six nonfinite parent failures are unavailable downstream, not deterioration observations. The full [RESULTS.md](RESULTS.md) states the mixed findings and limits.


Canonical bulk output is on Sapelo at `/scratch/yz54720/RSI2RSD/C4/dynamics_v1/results/`. This local Evidence directory retains compact, stage-verified copies of each completed cell's response summaries, fitted diagnostics, extension block summaries, code/config references, and verification report. It does not mirror per-step NPZ, logits, or checkpoints. Transfer route: authenticated `rsync` through `yz54720@xfer.gacrc.uga.edu` with included JSON/JSONL only; original raw files remain on Sapelo. The remote run uses code ID `rsd_c4.dynamics.v1` and Slurm arrays 48452662/48452757; the source code is in `Code/`.

## First verified set, 2026-09-22 17:50 EDT

| Cell | Remote source | Local compact files | Remote manifest check | Interpretation status |
|---|---|---:|---:|---|
| lambda1 beta.001 seed202 | `array48452662/point0_seed202_job48452663/` | 72; 2,504,756 bytes | 10,426 file hashes across 32 manifests; scheduler COMPLETED 0:0 | H20 responses finite; four-dimensional projection fails momentum closure |
| lambda1 beta.001 seed303 | `array48452662/point0_seed303_job48452664/` | 72; 2,505,116 bytes | 10,426 file hashes across 32 manifests; scheduler COMPLETED 0:0 | Same closure limitation |
| lambda.5 beta.001 seed202 | `array48452662/point2_seed202_job48452839/` | 72; 2,503,414 bytes | 10,426 file hashes across 32 manifests; scheduler COMPLETED 0:0 | Same closure limitation |

The local copy is an evidence slice, not a replacement for the remote hashed raw results. `verification.json` verifies existing manifests only; scientific coverage must also inspect `status.json`, every component exit code, and the source parent. Failed parent cells have no H20/extension files and will be listed as unavailable in the final matrix.

## Verified expansion and English status report, cutoff 2026-09-22 18:28 EDT

Three additional complete cells were checked against Slurm `COMPLETED 0:0`, zero component exit codes, and 32 present manifests with 10,426 hashed files per cell. Their filtered local mirrors have 72 files each:

| Cell | Remote source | Local mirror | Dynamics conclusion |
|---|---|---:|---|
| lambda.5 beta.001 seed303 | `array48452662/point2_seed303_job48456094/` | 2,503,601 bytes | Finite H20 responses; four-coordinate closure fails |
| lambda0 beta.001 seed202 | `array48452662/point4_seed202_job48456098/` | 2,451,171 bytes | Finite H20 responses; two diagnostic coordinates have zero scale, so standardized G/J is undefined |
| lambda0 beta.001 seed303 | `array48452662/point4_seed303_job48456099/` | 2,451,146 bytes | Same zero-scale limitation |

The six completed cells have 45 verified block summaries each. The two lambda0/beta.01 seeds202/303 were still running at the report cutoff; four viable seed404 supplements were dependency-queued. Six beta.01/lambda1 or.5 parent runs had previously terminated with nonfinite post-update loss and cannot supply downstream forks/extensions/H20. These statuses are frozen for the PDF and must not be silently refreshed in place.

- [English PDF snapshot](C4_Results_Snapshot_2026-09-22_1828_EDT_EN.pdf): 17 landscape pages; 18-cell status matrix; C4-1 through C4-7, including all 45 current-domain pre/post rows for each of the six complete cells.
- [Companion machine-readable tables](Snapshot_2026-09-22_1828_EDT/): `C4_coverage.csv` (18), `C4_signs.csv` (6), `C4_probes.csv` (540), `C4_cycles.csv` (18), `C4_blocks.csv` (270, with per-class selected counts), `C4_sweep.csv` (6), `C4_immediate.csv` (24), `C4_forks.csv` (72 horizon rows), `C4_dynamics.csv` (12 parent phases), `C4_xt.csv` (270), `C4_failures.csv` (6).
- [Manifest](Snapshot_2026-09-22_1828_EDT/MANIFEST.json): sizes and SHA256 for the PDF, build script and all 11 CSVs. The [builder](build_snapshot_report.py) asserts coverage, source-component status and manifest counts before reporting values.
- One-cycle grid compact evidence: `../Parameter_Grid_20260922/Evidence/compact/`, transferred from `/scratch/yz54720/RSI2RSD/C4/grid_single_replication_20260922/` through xfer; all six `failure.txt` traces are retained locally and contain the nonfinite post-update-loss exception. Existing baseline one-cycle and fork compact evidence: `../Seed_Replication_20260922/Evidence/job48431715/`.

Scientific readout: all six completed cells have finite empirical F at both parent phases. For lambda1/.5, the eight rank-four candidate fits fail the closure test; lambda0 has zero/unresolved coordinates. No system Jacobian, spectrum or phase transition is claimed. The PDF is a status snapshot, not the final 18-cell completion report. GitHub delivery of this new snapshot remains pending; only the `experiment/C4` branch under `C4/` is authorized.

## Subsequent verified 202/303 completion, 2026-09-22 19:29 EDT

The remaining two viable 202/303 cells finished after the 18:28 snapshot. Both Slurm tasks were `COMPLETED 0:0`; every component exited zero; each remote verification checked 32 manifests and 10,426 hashed files. The filtered local copies include JSON/JSONL and component logs; a fresh enumeration finds **856 locally present manifest members per cell**, all matching their hashes. The earlier 1,648-per-cell bookkeeping count was incorrect; it did not affect the remote 10,426-file verification or reported measurements. Each extension has 30 complete block summaries and 2,820 update records. [Detailed verification and correction](Evidence/VERIFY_NEW_COMPLETED_20260922_1925.json) preserves task and source paths.

| Cell | Remote source | New local compact evidence | Dynamics conclusion |
|---|---|---:|---|
| lambda0 beta.01 seed202 | `array48452662/point5_seed202_job48458661/` | 1,169 files, 15,005,376 bytes | Finite H20 responses; four-coordinate J unidentifiable |
| lambda0 beta.01 seed303 | `array48452662/point5_seed303_job48452662/` | 1,169 files, 15,004,881 bytes | Finite H20 responses; four-coordinate J unidentifiable |

Thus all eight viable 202/303 cells have completed three-cycle trajectories and H20 components. The four other 202/303 cells have unavailable parent checkpoints from the earlier numerical failures. These new results are **not included** in the frozen 18:28 PDF. At this verification, seed404 tasks 12/14/16 were running and task17 was queued; the two failed-parent 404 tasks had terminated without downstream components. Bulk checkpoints and per-step NPZ remain at the Sapelo source path above.

The [English stage analysis](RESULTS.md) combines the frozen six-cell report with the two new completed cells, while keeping the still-running 404 components out of result tables.

## Updated English PDF, cutoff 2026-09-22 20:10 EDT

- [31-page English PDF update](C4_Results_Update_2026-09-22_2010_EDT_EN.pdf) reports all 18 gamma-by-seed statuses, 11 verified three-cycle/H20 cells, six terminated numerical failures, and one still-running cell explicitly excluded from those result tables. It covers C4-1 through C4-7, including four block-level pseudo-supervision panels and every same-domain visit for the completed cells. The PDF was rendered on all 31 pages; full-resolution pages 1, 18, 19, and 20 were inspected without clipping or overlap.
- [Companion tables and manifest](Update_2026-09-22_2010_EDT/MANIFEST.json): 11 CSVs, with 18 coverage rows, 990 local probes, 495 block states, 33 cycle ends, 72 fork-horizon contrasts, 22 H20 parent phases, and six failure rows. The manifest records file sizes, SHA256, row counts, and visual/text checks. [Builder](build_update_report.py) is frozen to this cutoff and does not read unfinished seed-404 point 5 output.
- [Canonical English analysis](RESULTS.md) states the result and inference boundaries. The completed 404 cells, gamma (1,.001), (.5,.001), and (0,.001), each have Slurm `COMPLETED 0:0`, zero component exits, 32 remote manifests / 10,426 remote hashes, 856 matching locally mirrored manifest members, 30 extension blocks, 2,820 extension updates, and 132 finite H20 responses at each of two parents. [Verification record](Evidence/VERIFY_404_COMPLETED_20260922_2010.json) includes source paths and also verifies the 15 seed-404 first-cycle update logs retrieved through xfer.

The fourth viable seed-404 dynamics cell, gamma (0,.01), remained **running** at the PDF cutoff. Its previously verified one-cycle parent/forks are included only in the corresponding C4-5 tables. No provisional three-cycle/H20 values from that task appear in this PDF. The snapshot is immutable; after the task terminates, issue a separate complete-matrix report rather than silently changing this file. GitHub publication of the new batch remains pending and is limited to `experiment/C4` under `C4/`; `main` is unchanged.
