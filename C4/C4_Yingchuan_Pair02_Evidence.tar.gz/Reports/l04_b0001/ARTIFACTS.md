# Yingchuan checkpoint 2 artifacts

Parameter pair: **lambda=0.4, beta=0.001**, seeds 202/303/404/505/606. Sapelo array **48481042**. This is exploratory evidence; the confirmation panel was not read. The requested second-person parameter glance has not been confirmed and is not represented as completed.

- [English PDF](C4_Yingchuan_l04_b0001_EN.pdf): C4-1 through C4-7, complete five-seed status, unsmoothed student/teacher curves, fork contrasts, x/F/H20 diagnostics and explicit Jacobian limits. Eight landscape A4 pages, visually inspected.
- [Markdown source summary](RESULTS.md): observed readout and evidence boundaries.
- `C4_status.csv`, `C4_signs.csv`, `C4_cycles.csv`, `C4_blocks.csv`, `C4_returns.csv`, `C4_summary.csv`, `C4_forks.csv`, `C4_immediate.csv`, `C4_dynamics.csv`: machine-readable report tables.
- [Verification record](REPORT_VERIFICATION.json): output hashes, Slurm/component/coverage checks and visual QA.
- [Compact audit](../../Evidence/l04_b0001/AUDIT.json) and [SHA256 manifest](../../Evidence/l04_b0001/MANIFEST.json): 907 source files, 20,687,466 bytes, all rehashed locally without mismatch. The audit records five `COMPLETED 0:0` tasks, 45 blocks and four verified forks per seed, two 132/132 H20 analyses per seed and ten exact H93 shared-prefix comparisons.

Canonical raw results, checkpoints, logits, step tapes and worker logs remain under `/scratch/yz54720/RSI2RSD/C4/sweep_yingchuan_20260923/results/l04_b0001/`; the compact evidence originated from `/scratch/yz54720/RSI2RSD/C4/sweep_yingchuan_20260923/compact/l04_b0001/` and was transferred through `xfer.gacrc.uga.edu`. The long-horizon comparison records H93 as its latest scored checkpoint shared with the short fork; the two branches match on all ten such comparisons. No learner or run output was changed.
