# C4 Yingchuan checkpoint: lambda=0.4, beta=0.001

Source: Sapelo array 48481042; compact evidence `Evidence/l04_b0001/AUDIT.json` and `MANIFEST.json`.

All five prespecified seeds are terminal. The PDF and companion CSVs report C4-1 through C4-7. Missing or non-identifiable quantities are explicitly marked. These exploratory measurements do not establish persistent deterioration or a phase boundary.

| Seed | Parent blocks | Extension blocks | Full coverage | H1410 nodes | H20 analyses |
|---:|---:|---:|---|---:|---:|
| 202 | 15 | 30 | True | 2 | 2 |
| 303 | 15 | 30 | True | 2 | 2 |
| 404 | 15 | 30 | True | 2 | 2 |
| 505 | 15 | 30 | True | 2 | 2 |
| 606 | 15 | 30 | True | 2 | 2 |

## Descriptive readout

Same-domain visit-3 minus visit-1 CE is positive in 4/5 seeds (mean +0.090); mean classification-error change is -3.94 percentage points. H1410 closed acceptance is harmful in 5/10 correlated parent nodes, and the feedback interaction is positive in 7/10. These mixed exploratory signs do not establish sustained recursive deterioration.

The full scientific tables, unsmoothed student/teacher curves, audit bounds and missingness ledger are in the PDF. Companion CSV files preserve complete block, cycle, return, fork and dynamics records. Raw checkpoints, logits and step tapes remain on Sapelo. This is an English collaborator report; its evidence index is `ARTIFACTS.md`.
