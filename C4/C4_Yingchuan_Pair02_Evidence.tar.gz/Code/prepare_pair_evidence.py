"""Create a compact, hash-indexed copy of one terminal five-seed checkpoint.

Run on the Sapelo operator host after all five array tasks are terminal. This
copies report inputs only; raw logits, checkpoints and step archives remain in
the canonical result tree. A partial cell remains partial in the audit.
"""

import argparse
import hashlib
import json
import shutil
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SEEDS = (202, 303, 404, 505, 606)


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read(path):
    return json.loads(path.read_text())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("pair_key")
    parser.add_argument("--array", required=True)
    args = parser.parse_args()
    pair = args.pair_key
    cells = ROOT / "results" / pair
    out = ROOT / "compact" / pair
    out.mkdir(parents=True, exist_ok=False)
    source_files = []
    audit = {"pair": pair, "array": args.array, "cells": []}
    for seed in SEEDS:
        matches = list(cells.glob(f"seed{seed}_job*"))
        assert len(matches) == 1, (seed, matches)
        cell = matches[0]
        status = read(cell / "status.json")
        assert status["status"] != "running", (seed, status)
        parent = cell / "parent"
        extension = cell / "extension"
        parent_count = len(list(parent.glob("block_*/attempt_*/complete.json")))
        extension_count = len(list(extension.glob("block_*/attempt_*/complete.json")))
        forks = {}
        prefix_ok = {}
        for block in (5, 15):
            short = cell / f"fork_b{block}_h94"
            long = cell / f"fork_b{block}_h1410"
            forks[str(block)] = {}
            for horizon, directory in ((94, short), (1410, long)):
                verification = directory / "verification.json"
                forks[str(block)][str(horizon)] = (
                    read(verification).get("status") if verification.exists() else "unavailable"
                )
            if (short / "comparison.json").exists() and (long / "comparison.json").exists():
                # H93 is the latest scored checkpoint present in both horizons.
                a = {x["h"]: x for x in read(short / "comparison.json")}[93]
                b = {x["h"]: x for x in read(long / "comparison.json")}[93]
                keys = ("reject_closed", "reject_replay", "accept_closed", "accept_replay",
                        "A_closed", "A_open", "I_feedback")
                prefix_ok[str(block)] = all(abs(a[k] - b[k]) <= 1e-8 for k in keys)
            else:
                prefix_ok[str(block)] = None
        dynamics = {}
        for block in (5, 15):
            path = cell / f"dynamics_b{block}" / "dynamics_analysis.json"
            if not path.exists():
                dynamics[str(block)] = "unavailable"
            else:
                analysis = read(path)
                dynamics[str(block)] = (
                    "finite_132" if analysis.get("finite_responses") == 132
                    and analysis.get("total_responses") == 132 else "partial_or_nonfinite"
                )
        verification = read(cell / "verification.json") if (cell / "verification.json").exists() else {}
        verified = (
            status["status"] == "components_completed_coverage_review_required"
            and parent_count == 15 and extension_count == 30
            and all(v == "verified" for branch in forks.values() for v in branch.values())
            and all(v is True for v in prefix_ok.values())
            and all(v == "finite_132" for v in dynamics.values())
            and verification.get("status") == "verified_existing_manifests"
            and len(verification.get("markers", [])) == 32
        )
        audit["cells"].append({
            "seed": seed, "job": status["job"], "worker_status": status["status"],
            "components": status["components"], "parent_blocks": parent_count,
            "extension_blocks": extension_count, "fork_verification": forks,
            "h93_shared_prefix": prefix_ok, "dynamics_analysis": dynamics,
            "full_coverage_verified": verified,
        })
        patterns = (
            "status.json", "verification.json", "parent/config.json", "parent/status.json",
            "parent/fixed_q_initial.json", "parent/block_*/attempt_*/summary.json",
            "parent/block_*/attempt_*/updates.jsonl", "parent/block_*/attempt_*/complete.json",
            "extension/config.json", "extension/status.json", "extension/block_*/attempt_*/summary.json",
            "extension/block_*/attempt_*/updates.jsonl", "extension/block_*/attempt_*/complete.json",
            "fork_b*_h*/comparison.json", "fork_b*_h*/local_quality.json",
            "fork_b*_h*/verification.json", "fork_b*_h*/config.json",
            "dynamics_b*/dynamics_analysis.json", "dynamics_b*/responses.json",
            "dynamics_b*/status.json",
            "parent.log", "extension.log", "fork_*.log", "verify_*.log",
            "dynamics_*.log", "analysis_*.log", "verify_manifests.log",
        )
        for pattern in patterns:
            source_files.extend(p for p in cell.glob(pattern) if p.is_file())
    configs = [p for p in ROOT.glob("pair_??.json") if read(p).get("pair_key") == pair]
    assert len(configs) == 1, configs
    source_files.append(configs[0])
    receipt = configs[0].with_name(configs[0].stem + "_submission.json")
    assert receipt.exists(), receipt
    source_files.append(receipt)
    source_files.extend(p for p in (ROOT / "logs").glob(f"pair-{args.array}_*.out"))
    source_files.extend(p for p in (ROOT / "logs").glob(f"pair-{args.array}_*.err"))
    records = []
    for source in sorted(set(source_files)):
        rel = source.relative_to(ROOT)
        dest = out / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, dest)
        records.append({"path": str(rel), "source": str(source), "bytes": source.stat().st_size,
                        "sha256": digest(dest)})
    audit["scheduler_accounting"] = subprocess.check_output(
        ["sacct", "-j", args.array, "--format=JobID,State,ExitCode,Elapsed,NodeList",
         "-P", "-n"], text=True
    )
    (out / "AUDIT.json").write_text(json.dumps(audit, indent=2, default=str) + "\n")
    (out / "MANIFEST.json").write_text(json.dumps({"source_root": str(ROOT),
        "files": records}, indent=2) + "\n")
    print(json.dumps({"compact": str(out), "files": len(records),
        "bytes": sum(r["bytes"] for r in records),
        "full_coverage": sum(x["full_coverage_verified"] for x in audit["cells"])}, indent=2))


if __name__ == "__main__":
    main()
