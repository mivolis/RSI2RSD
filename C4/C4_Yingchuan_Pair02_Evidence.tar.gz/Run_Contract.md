# Yingchuan C4 sweep — run contract

Source: user-supplied `Split (1).pdf`, pp. 1, 6–7, dated 2026-09-22. This assignment supersedes the former recommendation to stop the exploratory parameter sweep for the named cells only. It does not change the interpretation of prior results.

## Frozen matrix and checkpoint order

Yingchuan owns exactly 40 new cells: λ=0.4 followed by λ=0.7; at each λ, β increases **0.0005 → 0.001 → 0.0015 → 0.002**; each pair has seeds **202, 303, 404, 505, 606**. Finish all five seeds, audit their terminal or explicitly failed states, and publish one English PDF in the style of `Dynamics_Completion_20260922/C4_Results_Full_2026-09-22_EN.pdf` **before submitting the next β**. Complete all four β checkpoints for λ=0.4 before submitting λ=0.7. No other assignee's cells are in scope.

| Checkpoint | λ | β | Seeds | Gate before next launch |
|---|---:|---:|---|---|
| 1 | 0.4 | 0.0005 | 202/303/404/505/606 | PDF + verification |
| 2 | 0.4 | 0.001 | same five | PDF + verification |
| 3 | 0.4 | 0.0015 | same five | PDF + verification |
| 4 | 0.4 | 0.002 | same five | PDF + verification |
| 5 | 0.7 | 0.0005 | same five | PDF + verification |
| 6 | 0.7 | 0.001 | same five | PDF + verification |
| 7 | 0.7 | 0.0015 | same five | PDF + verification |
| 8 | 0.7 | 0.002 | same five | final PDF + verification |

The PDF explicitly warns that β=0.0005 must not become 0.005. Before submission, print the immutable per-pair configuration, compare it independently with the table above and the PDF, and arrange the requested second-person glance at the exact launch values. No array containing later β values may be queued ahead of a prior pair's report.

## Per-cell scientific output

Use the frozen C4 learner and audit, changing only the CLI allowance for the new λ values. At each seed, train a one-cycle parent; preserve the first nonempty next-domain candidate after blocks 5 and 15 and their H94/H1410 closed/replay forks; continue from block 15 to a three-cycle trajectory; measure both parent phases with the existing H20 independent perturbation and closure protocol. Keep the reserved confirmation audit untouched. A parent numerical failure remains a reported failure; continue any earlier usable fixed parent without imputing missing later quantities.

At each five-seed checkpoint, report C4-1 through C4-7 as in the prior full PDF: complete status matrix; local proxy/labelled signs; fixed-Q student/teacher, pseudo-supervision and coverage; all same-domain returns; parameter/cost summary; four branch risks and immediate/H94/H1409/H1410 contrasts; x_t, empirical F, finite G, perturbation/conditioning/held-out/closure diagnostics; and a bounded parameter-map readout. Mark every missing or non-identifiable quantity and retain negative, null and improving cases. Reuse its landscape-A4 style, tables, raw-curve policy and appendix logic, but recompute all values from this pair's verified data. Do not copy its 12/18-cell conclusions, claim a Jacobian from finite response alone, or label a numerical failure as recursive deterioration. Seeds reused across pairs are paired comparisons, not independent cross-parameter replications.

## Execution and provenance

Remote canonical workspace: `/scratch/yz54720/RSI2RSD/C4/sweep_yingchuan_20260923/`; code ID `rsd_c4.yingchuan_sweep.v1`. Keep the historical `/scratch/yz54720/RSI2RSD/C4/` core and old results unchanged. One GPU per seed task; at most three concurrent C4 tasks, subject to current Sapelo resource availability and other running jobs. No paid instance. Use Operator SSH for code and Slurm; xfer only for transfer. Before each pair, test the code and resource configuration, avoid duplicate submission, then record the job IDs, logs, seed-to-task map, SHA256 code identity and exact outputs. All 40 seeds remain exploratory; do not touch the confirmation panel.

Sapelo keeps bulk checkpoints, logits and raw steps. Retrieve the compact evidence actually needed for a report into this experiment directory, with source paths and checksums. Each checkpoint gets its own dated `Reports/` PDF, Markdown source, CSV tables and verification record. After a report is created, inspect its rendered pages before unlocking the next pair. GitHub delivery, if used, stays on `mivolis/RSI2RSD` branch `experiment/C4` under `C4/`; never modify `main`.

## Acceptance of each checkpoint

For all five seeds, reconcile `sacct` terminal state/exit code with the worker's component status, parent/extension block counts, fork verification and H20 manifests. Preserve failed attempts and explain missing descendants. The report must visibly distinguish observed values, interpretations, failed components, and quantities not identified. A scheduler `COMPLETED` status or `verify_cell.py` alone is insufficient to call a cell complete. The report and its source/evidence index must be saved and linked before the next β is submitted.
