#!/usr/bin/env python3
"""Build one evidence-grounded, five-seed C4 checkpoint report.

Input is the compact Sapelo copy produced by prepare_pair_evidence.py. This
script never reads model outputs outside that copy or the confirmation panel.
"""

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path

from reportlab.graphics.shapes import Drawing, Line, PolyLine, String
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.platypus import (LongTable, PageBreak, Paragraph,
                               SimpleDocTemplate, Spacer, TableStyle)


PROJECT = Path(__file__).resolve().parent
SEEDS = (202, 303, 404, 505, 606)
BLUE = colors.HexColor("#2066A3")
INK = colors.HexColor("#14283B")
PALE = colors.HexColor("#EAF0F6")


def read(path):
    return json.loads(path.read_text())


def f(value, digits=3):
    return "n/a" if value is None else f"{value:.{digits}f}"


def lines(path):
    return [json.loads(s) for s in path.read_text().splitlines() if s.strip()]


def summarize_blocks(root):
    summaries = {}
    updates = []
    for path in root.glob("block_*/attempt_*/summary.json"):
        item = read(path)
        summaries[item["block"]] = item
        logfile = path.with_name("updates.jsonl")
        if logfile.exists():
            updates.extend(lines(logfile))
    return summaries, updates


def concentration(counts):
    total = sum(counts)
    if total == 0:
        return None
    return 1 + sum((v / total) * math.log(v / total) for v in counts if v) / math.log(100)


def collect(compact):
    audit = read(compact / "AUDIT.json")
    manifest = read(compact / "MANIFEST.json")
    for item in manifest["files"]:
        path = compact / item["path"]
        assert path.exists() and path.stat().st_size == item["bytes"], path
        assert hashlib.sha256(path.read_bytes()).hexdigest() == item["sha256"], path
    cells = []
    for info in audit["cells"]:
        seed = info["seed"]
        matches = list((compact / "results" / audit["pair"]).glob(f"seed{seed}_job*"))
        assert len(matches) == 1, (seed, matches)
        root = matches[0]
        ps, pu = summarize_blocks(root / "parent")
        es, eu = summarize_blocks(root / "extension")
        blocks = {**ps, **es}
        updates = pu + eu
        trajectory = sorted(blocks) == list(range(45))
        probes = [u for u in updates if u.get("local_probe") and u.get("updated")
                  and u.get("proxy_delta") is not None and u.get("local_delta") is not None]
        signs = {k: 0 for k in ("both_improve", "proxy_down_local_up", "proxy_up_local_down",
                                 "both_worsen", "near_zero")}
        for u in probes:
            x, y = u["proxy_delta"], u["local_delta"]
            if abs(x) < 1e-4 or abs(y) < 1e-4:
                signs["near_zero"] += 1
            elif x < 0 and y < 0:
                signs["both_improve"] += 1
            elif x < 0 and y > 0:
                signs["proxy_down_local_up"] += 1
            elif x > 0 and y < 0:
                signs["proxy_up_local_down"] += 1
            else:
                signs["both_worsen"] += 1
        forks, immediate = [], []
        for parent_block in (5, 15):
            short = root / f"fork_b{parent_block}_h94"
            long = root / f"fork_b{parent_block}_h1410"
            if not (short / "comparison.json").exists() or not (long / "comparison.json").exists():
                continue
            short_rows = {r["h"]: r for r in read(short / "comparison.json")}
            long_rows = {r["h"]: r for r in read(long / "comparison.json")}
            for h in (94, 1409, 1410):
                row = (short_rows if h == 94 else long_rows).get(h)
                if row:
                    forks.append({"seed": seed, "parent": parent_block, "h": h, **row})
            qpath = long / "local_quality.json"
            if qpath.exists():
                q = read(qpath)
                immediate.append({"seed": seed, "parent": parent_block,
                    "q_dce": q["accept"]["q"]["student"]["ce"] - q["reject"]["q"]["student"]["ce"],
                    "q_derr": q["accept"]["q"]["student"]["error"] - q["reject"]["q"]["student"]["error"],
                    "domain_dce": q["accept"]["current_domain"]["student"]["ce"] - q["reject"]["current_domain"]["student"]["ce"],
                    "domain_derr": q["accept"]["current_domain"]["student"]["error"] - q["reject"]["current_domain"]["student"]["error"]})
        dynamics = []
        for parent_block in (5, 15):
            directory = root / f"dynamics_b{parent_block}"
            path = directory / "dynamics_analysis.json"
            if not path.exists():
                continue
            analysis = read(path)
            responses = read(directory / "responses.json")
            base = next((r for r in responses if r["obj"] == "base"), None)
            fits = analysis.get("fits", {})
            fit = fits.get("0.0001")
            gains = [g["gain"] for g in analysis.get("gains", []) if g.get("gain") is not None]
            dynamics.append({"seed": seed, "parent": parent_block, "x0": base["x0"] if base else None,
                "F": analysis.get("F_at_parent"), "F_sd": analysis.get("F_tape_sd"),
                "finite": analysis.get("finite_responses"), "total": analysis.get("total_responses"),
                "median_G": sorted(gains)[len(gains)//2] if gains else None,
                "resolved": analysis.get("coordinate_resolved"),
                "rank": fit.get("rank") if fit else None,
                "condition": fit.get("condition") if fit else None,
                "heldout": fit.get("validation_residuals") if fit else None,
                "closure_falsified": fit.get("closure_falsified") if fit else None,
                "scale_difference": analysis.get("relative_scale_difference"),
                "reason": analysis.get("reason", "not established")})
        cycles, domain_returns, summary = [], [], None
        if trajectory:
            for cycle in range(3):
                subset = [blocks[i] for i in range(cycle*15, (cycle+1)*15)]
                selected = sum(b["selected"] for b in subset)
                images = sum(b["images"] for b in subset)
                counts = [sum(b["counts_selected"][j] for b in subset) for j in range(100)]
                q = subset[-1]["fixed_q"]
                cycles.append({"seed": seed, "cycle": cycle+1,
                    "student_ce": q["student"]["ce"], "student_error": q["student"]["error"],
                    "teacher_ce": q["teacher"]["ce"], "teacher_error": q["teacher"]["error"],
                    "mixed_ce": q["diagnostic_state"][1], "js": q["diagnostic_state"][2],
                    "confidence": q["diagnostic_state"][3],
                    "noise_all": sum(b["wrong_all"] for b in subset)/images,
                    "noise_selected": sum(b["wrong_selected"] for b in subset)/selected if selected else None,
                    "coverage": selected/images, "concentration": concentration(counts),
                    "disagreement": sum(b["disagreements"] for b in subset)/images,
                    "steps": sum(b["optimizer_steps"] for b in subset),
                    "empty_masks": sum(b["empty_masks"] for b in subset),
                    "seconds": sum(b["seconds_including_checkpoint"] for b in subset)})
            for j in range(15):
                first, last = blocks[j], blocks[30+j]
                domain_returns.append({"seed": seed, "domain": first["domain"],
                    "visit1_post_ce": first["post"]["student"]["ce"],
                    "visit3_post_ce": last["post"]["student"]["ce"],
                    "delta_ce": last["post"]["student"]["ce"] - first["post"]["student"]["ce"],
                    "delta_error": last["post"]["student"]["error"] - first["post"]["student"]["error"]})
            summary = {"seed": seed, "mean_post_ce": sum(b["post"]["student"]["ce"] for b in blocks.values())/45,
                "mean_post_error": sum(b["post"]["student"]["error"] for b in blocks.values())/45,
                "return_dce": sum(r["delta_ce"] for r in domain_returns)/15,
                "return_derr": sum(r["delta_error"] for r in domain_returns)/15,
                "cycle3_ce": sum(blocks[i]["post"]["student"]["ce"] for i in range(30,45))/15,
                "cycle3_error": sum(blocks[i]["post"]["student"]["error"] for i in range(30,45))/15,
                "coverage": sum(b["selected"] for b in blocks.values())/sum(b["images"] for b in blocks.values()),
                "steps": sum(b["optimizer_steps"] for b in blocks.values()),
                "minutes": sum(b["seconds_including_checkpoint"] for b in blocks.values())/60}
        cells.append({"seed": seed, "root": root, "audit": info, "blocks": blocks,
                      "updates": updates, "trajectory": trajectory, "probes": probes,
                      "signs": signs, "forks": forks, "immediate": immediate,
                      "dynamics": dynamics, "cycles": cycles,
                      "domain_returns": domain_returns, "summary": summary})
    return audit, cells


def write_csv(path, rows):
    if not rows:
        path.write_text("")
        return
    fields = list(dict.fromkeys(k for row in rows for k in row))
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows({k: json.dumps(v) if isinstance(v, (list, dict)) else v for k, v in row.items()} for row in rows)


def plot_trajectories(cells):
    complete = [c for c in cells if c["trajectory"]]
    if not complete:
        return None
    drawing = Drawing(770, 220)
    palette = ("#2066A3", "#D7833C", "#399A75", "#8A5AA3", "#C45D6E")
    for panel, field, title in ((0, "ce", "Fixed-Q cross-entropy"),
                                (1, "error", "Fixed-Q classification error (%)")):
        left = 42 + panel * 385
        bottom, width, height = 35, 328, 145
        drawing.add(String(left, 196, title, fontSize=9, fillColor=INK))
        drawing.add(Line(left, bottom, left+width, bottom, strokeColor=INK, strokeWidth=.6))
        drawing.add(Line(left, bottom, left, bottom+height, strokeColor=INK, strokeWidth=.6))
        values = [c["blocks"][i]["fixed_q"]["student"][field] * (100 if field == "error" else 1)
                  for c in complete for i in range(45)]
        ymin, ymax = min(values), max(values)
        pad = max((ymax-ymin)*.08, .01)
        ymin, ymax = ymin-pad, ymax+pad
        drawing.add(String(left-29, bottom, f"{ymin:.2f}", fontSize=6, fillColor=INK))
        drawing.add(String(left-29, bottom+height, f"{ymax:.2f}", fontSize=6, fillColor=INK))
        for boundary in (15.5, 30.5):
            xx = left + (boundary-1)/44*width
            drawing.add(Line(xx, bottom, xx, bottom+height,
                             strokeColor=colors.HexColor("#BEC9D4"), strokeWidth=.5))
        for index, cell in enumerate(complete):
            points = []
            for i in range(45):
                val = cell["blocks"][i]["fixed_q"]["student"][field] * (100 if field == "error" else 1)
                points.extend((left+i/44*width, bottom+(val-ymin)/(ymax-ymin)*height))
            color = colors.HexColor(palette[index])
            drawing.add(PolyLine(points, strokeColor=color, strokeWidth=1.1))
            drawing.add(String(left+index*63, 12, str(cell["seed"]), fontSize=7, fillColor=color))
    return drawing


def build_pdf(audit, cells, out, pair_label, plot):
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="C4Title", parent=styles["Title"], fontName="Helvetica-Bold",
                              fontSize=16, leading=19, textColor=INK, alignment=TA_CENTER))
    styles.add(ParagraphStyle(name="C4Head", parent=styles["Heading2"], fontName="Helvetica-Bold",
                              fontSize=10.5, leading=13, textColor=BLUE, spaceBefore=9, spaceAfter=5))
    styles.add(ParagraphStyle(name="C4Body", parent=styles["BodyText"], fontName="Helvetica",
                              fontSize=8, leading=10.5, textColor=INK, spaceAfter=5))
    styles.add(ParagraphStyle(name="C4Small", parent=styles["BodyText"], fontName="Helvetica",
                              fontSize=6.8, leading=8.5, textColor=INK, spaceAfter=3))
    pdf = out / f"C4_Yingchuan_{audit['pair']}_EN.pdf"
    doc = SimpleDocTemplate(str(pdf), pagesize=landscape(A4), leftMargin=34,
                            rightMargin=34, topMargin=33, bottomMargin=30,
                            title=f"C4 Yingchuan {pair_label}")
    W = landscape(A4)[0] - 68
    story = []
    def P(text, style="C4Body"):
        story.append(Paragraph(str(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"), styles[style]))
    def H(text): P(text, "C4Head")
    def T(rows, widths=None, size=7):
        widths = widths or [W / len(rows[0])] * len(rows[0])
        shaped = [[Paragraph(str(item).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"), styles["C4Small"]) for item in row] for row in rows]
        table = LongTable(shaped, colWidths=widths, repeatRows=1, hAlign="LEFT")
        table.setStyle(TableStyle([("BACKGROUND", (0,0), (-1,0), PALE),
            ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#F7F9FB")]),
            ("LINEBELOW", (0,0), (-1,0), .6, BLUE), ("VALIGN", (0,0), (-1,-1), "TOP"),
            ("LEFTPADDING", (0,0), (-1,-1), 3), ("RIGHTPADDING", (0,0), (-1,-1), 3),
            ("TOPPADDING", (0,0), (-1,-1), 2), ("BOTTOMPADDING", (0,0), (-1,-1), 2)]))
        story.append(table)
        story.append(Spacer(1, 5))
    def page(): story.append(PageBreak())
    P(f"C4: Yingchuan parameter checkpoint {pair_label}", "C4Title")
    P(f"Sapelo array {audit['array']}; five prespecified exploratory seeds. This is one of eight sequential checkpoints. All five jobs are terminal before this report; no next beta was launched for its construction.")
    P("Evidence boundary: measured CIFAR-100-C severity-5 trajectories and finite intervention responses. Numerical failure is a failed computation, not behavioral deterioration. A finite F response does not identify a closed Jacobian, spectrum or phase transition.")
    H("Complete five-seed status")
    status_rows = [["Seed", "Parent blocks", "Extension blocks", "Forks verified", "H20 analyses", "Coverage / reason"]]
    for cell in cells:
        a = cell["audit"]
        nv = sum(v == "verified" for d in a["fork_verification"].values() for v in d.values())
        nd = sum(v == "finite_132" for v in a["dynamics_analysis"].values())
        status_rows.append([str(cell["seed"]), str(a["parent_blocks"]), str(a["extension_blocks"]),
                            f"{nv}/4", f"{nd}/2", "complete" if a["full_coverage_verified"] else a["worker_status"]])
    T(status_rows, [44, 95, 100, 105, 95, W-439])
    P("A component is reported only after its own completion and verification. Parent, extension, fork and H20 gaps remain explicit; the raw run and failed attempts remain on Sapelo.")
    H("C4-1. Proxy versus labelled local update")
    P("Negative post-minus-pre CE means local improvement. Near zero means either absolute change is below 1e-4. Natural C4 executes updates without a separate accept/reject evaluator.")
    rows = [["Seed", "Probes", "Both improve", "Proxy down / local up", "Proxy up / local down", "Both worsen", "Near zero"]]
    for c in cells:
        s = c["signs"]
        rows.append([str(c["seed"]), str(len(c["probes"])), str(s["both_improve"]),
                     str(s["proxy_down_local_up"]), str(s["proxy_up_local_down"]),
                     str(s["both_worsen"]), str(s["near_zero"])])
    T(rows, [43, 48, 86, 150, 150, 95, W-572])
    page()
    H("C4-2. Complete fixed-Q trajectories and pseudo-supervision")
    P("The fixed-Q panel uses the same 1,500 image-corruption evaluations at every block. Curves are unsmoothed. Dotted curves are teachers; solid curves are students. Missing/failed cells are absent, not assigned zero risk.")
    if plot is not None:
        story.append(plot)
    rows = [["Seed", "Cycle", "Student CE / err%", "Teacher CE / err%", "Mixed CE / JS", "Noise all / selected%", "Coverage / conc.", "Steps / empty"]]
    for c in cells:
        for r in c["cycles"]:
            rows.append([str(c["seed"]), str(r["cycle"]), f"{f(r['student_ce'])} / {f(100*r['student_error'],1)}",
                f"{f(r['teacher_ce'])} / {f(100*r['teacher_error'],1)}",
                f"{f(r['mixed_ce'])} / {f(r['js'],4)}",
                f"{f(100*r['noise_all'],1)} / {f(100*r['noise_selected'],1)}",
                f"{f(100*r['coverage'],1)} / {f(r['concentration'],3)}",
                f"{r['steps']} / {r['empty_masks']}"])
    T(rows, [42, 40, 105, 105, 105, 113, 105, W-615])
    P("Cycle CSV retains teacher/student disagreement, mixed-target confidence, count-weighted pseudo-label statistics, selected-class concentration and elapsed block time. Selected noise is undefined when no examples were selected.")
    page()
    H("C4-3. Same-domain returns")
    P("Visit-3 minus visit-1 post-block student CE for each named corruption. Positive means worse on that domain; all domains and all terminal cells are retained. The companion block CSV includes pre/post CE and error for student and teacher at every visit.")
    domains = [r["domain"] for c in cells for r in c["domain_returns"] if c["seed"] == next((z["seed"] for z in cells if z["trajectory"]), -1)]
    rows = [["Corruption"] + [str(seed) for seed in SEEDS]]
    for domain in dict.fromkeys(domains):
        rows.append([domain] + [f(next((r["delta_ce"] for c in cells if c["seed"] == seed for r in c["domain_returns"] if r["domain"] == domain), None)) for seed in SEEDS])
    T(rows, [150] + [(W-150)/5]*5)
    H("C4-4. Per-seed parameter summary")
    rows = [["Seed", "Mean post CE / err%", "Mean return dCE / dErr pp", "Cycle-3 CE / err%", "Coverage%", "Updates", "Block cost min"]]
    for c in cells:
        r = c["summary"]
        rows.append([str(c["seed"]), f"{f(r['mean_post_ce'])} / {f(100*r['mean_post_error'],1)}" if r else "unavailable",
            f"{f(r['return_dce'])} / {f(100*r['return_derr'],2)}" if r else "unavailable",
            f"{f(r['cycle3_ce'])} / {f(100*r['cycle3_error'],1)}" if r else "unavailable",
            f(100*r["coverage"],1) if r else "n/a", str(r["steps"]) if r else "n/a",
            f(r["minutes"],1) if r else "n/a"])
    T(rows, [42, 140, 167, 135, 72, 61, W-617])
    page()
    H("C4-5. Matched accept/reject and closed/replay forks")
    P("The first nonempty update after preselected blocks 5 and 15 is the focal candidate. Positive accept-minus-reject CE is worse. A_closed = accept_closed - reject_closed; A_open = accept_replay - reject_replay; I_feedback = A_closed - A_open. H94 is the common prefix of H1410, not a second independent replicate.")
    rows = [["Seed", "Parent", "Immediate Q dCE / dErr pp", "Immediate domain dCE / dErr pp"]]
    for c in cells:
        for r in c["immediate"]:
            rows.append([str(c["seed"]), str(r["parent"]),
                f"{f(r['q_dce'])} / {f(100*r['q_derr'],2)}",
                f"{f(r['domain_dce'])} / {f(100*r['domain_derr'],2)}"])
    T(rows, [50, 50, 270, W-370])
    for horizon in (94, 1409, 1410):
        H(f"H{horizon} fixed-Q CE contrasts")
        rows = [["Seed", "Parent", "R closed", "R replay", "A closed", "A replay", "A_closed", "A_open", "I_feedback"]]
        for c in cells:
            for r in c["forks"]:
                if r["h"] == horizon:
                    rows.append([str(c["seed"]), str(r["parent"]), f(r["reject_closed"]),
                        f(r["reject_replay"]), f(r["accept_closed"]), f(r["accept_replay"]),
                        f(r["A_closed"]), f(r["A_open"]), f(r["I_feedback"])])
        T(rows, [43, 47] + [(W-90)/7]*7)
        if horizon != 1410:
            page()
    page()
    H("C4-6. Diagnostic state, finite F and local identifiability")
    P("x=(student fixed-Q CE, mixed-target fixed-Q CE, student/teacher JS, mixed confidence). F is the mean H20 future x over three base tapes at each observed parent; it is a conditional response, not a closed transition law. The block CSV stores every observed x_t.")
    rows = [["Seed", "Parent", "x0", "F_H20(x0)", "Tape SD", "Finite", "J status"]]
    for c in cells:
        for r in c["dynamics"]:
            vec = lambda v: " / ".join(f(z,3) for z in v) if v else "n/a"
            rows.append([str(c["seed"]), str(r["parent"]), vec(r["x0"]), vec(r["F"]),
                vec(r["F_sd"]), f"{r['finite']}/{r['total']}", "not identified" if r["closure_falsified"] or r["rank"] is None else "fit only; review closure"])
    T(rows, [39, 42, 188, 188, 163, 61, W-681])
    H("Perturbation, conditioning and held-out diagnostics")
    rows = [["Seed", "Parent", "Median G", "Rank", "Condition", "Scale diff", "Held-out median", "Closure", "Reason"]]
    for c in cells:
        for r in c["dynamics"]:
            val = r["heldout"]
            median = sorted(val)[len(val)//2] if val else None
            rows.append([str(c["seed"]), str(r["parent"]), f(r["median_G"],1),
                str(r["rank"]) if r["rank"] is not None else "not fit", f(r["condition"],1),
                f(r["scale_difference"],2), f(median,2),
                "falsified" if r["closure_falsified"] else "unresolved", str(r["reason"])[:100]])
    T(rows, [40, 43, 65, 48, 75, 70, 100, 80, W-521])
    P("Independent student/teacher perturbations, input rank/condition, two scales, held-out directions and momentum closure checks are retained in the compact analysis files. No eigenvalue or phase boundary is claimed without a closed and predictive state law.")
    page()
    H("C4-7. Bounded parameter-map reading")
    P(f"This checkpoint isolates one pair {pair_label} with five exploratory seeds. Seeds are reused across later pairs for paired comparison; they are not independent cross-parameter replications. Outcomes at this pair alone cannot locate a stability boundary. Numerical failures and improvement/null findings remain in the reported denominator.")
    nfull = sum(c["trajectory"] for c in cells)
    nharm = sum(r["A_closed"] > 0 for c in cells for r in c["forks"] if r["h"] == 1410)
    nnode = sum(r["h"] == 1410 for c in cells for r in c["forks"])
    nfeedback = sum(r["I_feedback"] > 0 for c in cells for r in c["forks"] if r["h"] == 1410)
    P(f"Observed coverage: {nfull}/5 complete 45-block trajectories, {nnode} verified H1410 parent nodes, {nharm} positive A_closed and {nfeedback} positive I_feedback. Parent nodes within one seed are correlated. A positive endpoint or interaction alone does not establish sustained recursive deterioration.")
    H("Coverage ledger and missingness")
    rows = [["C4 item", "Present evidence", "Missing / limitation"]]
    rows.extend([
        ["C4-1", f"{sum(len(c['probes']) for c in cells)} completed local probes", "Unavailable after failed/incomplete trajectories"],
        ["C4-2", f"{nfull} full trajectories and cycle process records", "Failed/partial cells not extrapolated"],
        ["C4-3", f"{sum(len(c['domain_returns']) for c in cells)} same-domain return comparisons", "Only complete first/third visits"],
        ["C4-4", f"{nfull} per-seed parameter summaries", "One pair cannot characterize a sweep"],
        ["C4-5", f"{sum(len(c['forks']) for c in cells)} fork horizons", "Unavailable parent nodes explicitly excluded"],
        ["C4-6", f"{sum(len(c['dynamics']) for c in cells)} H20 parent analyses", "J/spectrum only if closure and held-out criteria pass"],
        ["C4-7", "One-pair status/sign description", "No identified region or boundary"],
    ])
    T(rows, [75, 350, W-425])
    P(f"Provenance: Sapelo {audit['array']}, compact evidence MANIFEST.json and AUDIT.json. Raw checkpoints, logits, step tapes and all failures remain under /scratch/yz54720/RSI2RSD/C4/sweep_yingchuan_20260923/results/{audit['pair']}/. The reserved confirmation panel was not read.")

    def footer(canvas, current):
        canvas.saveState()
        canvas.setFont("Helvetica", 7)
        canvas.setFillColor(colors.HexColor("#657688"))
        canvas.line(34, 25, landscape(A4)[0]-34, 25)
        canvas.drawString(34, 15, f"C4 Yingchuan checkpoint | {pair_label} | verified components only")
        canvas.drawRightString(landscape(A4)[0]-34, 15, f"Page {current.page}")
        canvas.restoreState()
    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    return pdf


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("pair_key")
    args = parser.parse_args()
    compact = PROJECT / "Evidence" / args.pair_key
    audit, cells = collect(compact)
    configs = [p for p in compact.glob("pair_??.json") if read(p).get("pair_key") == args.pair_key]
    assert len(configs) == 1, configs
    config = read(configs[0])
    pair_label = f"lambda={config['lambda']}, beta={config['beta']}"
    out = PROJECT / "Reports" / args.pair_key
    out.mkdir(parents=True, exist_ok=True)
    for name, rows in {
        "status": [{k:v for k,v in c["audit"].items() if k != "components"} for c in cells],
        "signs": [{"seed":c["seed"], "probes":len(c["probes"]), **c["signs"]} for c in cells],
        "cycles": [r for c in cells for r in c["cycles"]],
        "blocks": [{"seed":c["seed"], "block":i, "cycle":i//15+1,
            "domain":b["domain"], "student_pre_ce":b["pre"]["student"]["ce"],
            "student_post_ce":b["post"]["student"]["ce"],
            "student_pre_error":b["pre"]["student"]["error"],
            "student_post_error":b["post"]["student"]["error"],
            "teacher_pre_ce":b["pre"]["teacher"]["ce"],
            "teacher_post_ce":b["post"]["teacher"]["ce"],
            "teacher_pre_error":b["pre"]["teacher"]["error"],
            "teacher_post_error":b["post"]["teacher"]["error"],
            "x_t":b["fixed_q"]["diagnostic_state"],
            "coverage":b["selected"]/b["images"],
            "pseudo_noise_all":b["wrong_all"]/b["images"],
            "pseudo_noise_selected":b["wrong_selected"]/b["selected"] if b["selected"] else None,
            "selected_counts_by_class":b["counts_selected"],
            "disagreement":b["disagreements"]/b["images"],
            "optimizer_steps":b["optimizer_steps"], "empty_masks":b["empty_masks"],
            "seconds":b["seconds_including_checkpoint"]}
            for c in cells for i,b in sorted(c["blocks"].items())],
        "returns": [r for c in cells for r in c["domain_returns"]],
        "summary": [c["summary"] for c in cells if c["summary"]],
        "forks": [r for c in cells for r in c["forks"]],
        "immediate": [r for c in cells for r in c["immediate"]],
        "dynamics": [r for c in cells for r in c["dynamics"]],
    }.items():
        write_csv(out / f"C4_{name}.csv", rows)
    plot = plot_trajectories(cells)
    pdf = build_pdf(audit, cells, out, pair_label, plot)
    md = [f"# C4 Yingchuan checkpoint: {pair_label}", "", f"Source: Sapelo array {audit['array']}; compact evidence `Evidence/{args.pair_key}/AUDIT.json` and `MANIFEST.json`.",
          "", "All five prespecified seeds are terminal. The PDF and companion CSVs report C4-1 through C4-7. Missing or non-identifiable quantities are explicitly marked. These exploratory measurements do not establish persistent deterioration or a phase boundary.",
          "", "| Seed | Parent blocks | Extension blocks | Full coverage | H1410 nodes | H20 analyses |", "|---:|---:|---:|---|---:|---:|"]
    for c in cells:
        a = c["audit"]
        md.append(f"| {c['seed']} | {a['parent_blocks']} | {a['extension_blocks']} | {a['full_coverage_verified']} | {sum(r['h']==1410 for r in c['forks'])} | {len(c['dynamics'])} |")
    md.extend(["", "The full scientific tables, unsmoothed curves, audit bounds and missingness ledger are in the PDF. CSV files preserve all complete block, cycle, return, fork and dynamics records. Raw outputs remain on Sapelo.", ""])
    (out / "RESULTS.md").write_text("\n".join(md))
    print(json.dumps({"pdf":str(pdf), "bytes":pdf.stat().st_size,
        "complete_trajectories":sum(c["trajectory"] for c in cells),
        "full_coverage":sum(c["audit"]["full_coverage_verified"] for c in cells)}, indent=2))


if __name__ == "__main__":
    main()
