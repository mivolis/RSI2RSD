"""Run one prespecified Yingchuan C4 (lambda, beta, seed) cell on one GPU.

The only learner change from the archived C4 is acceptance of lambda .4/.7 at
the CLI. All components and failures are retained separately; a supervisor
exit code is not a scientific completion certificate.
"""

import hashlib
import json
import os
import subprocess
import sys
import time
from decimal import Decimal
from pathlib import Path


ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
CONFIG = Path(os.environ["C4_PAIR_CONFIG"]).resolve()
config_bytes = CONFIG.read_bytes()
CONFIG_SHA256 = hashlib.sha256(config_bytes).hexdigest()
config = json.loads(config_bytes)
lam = Decimal(config["lambda"])
beta = Decimal(config["beta"])
assert lam in (Decimal("0.4"), Decimal("0.7")), lam
assert beta in (Decimal("0.0005"), Decimal("0.001"), Decimal("0.0015"), Decimal("0.002")), beta
assert config["seeds"] == [202, 303, 404, 505, 606]
task = int(os.environ["SLURM_ARRAY_TASK_ID"])
seed = config["seeds"][task]
assert 0 <= task < 5
job = os.environ["SLURM_JOB_ID"]
pair = config["pair_key"]
assert pair == f"l{str(lam).replace('.', '')}_b{str(beta).replace('.', '')}", pair
out = ROOT / "results" / pair / f"seed{seed}_job{job}"
out.mkdir(parents=True, exist_ok=False)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


code_files = [ROOT / x for x in (
    "c4.py", "forks.py", "run_measured_fork.py", "verify_forks.py",
    "dynamics_v1/extend_trajectory.py", "dynamics_v1/run_dynamics.py",
    "dynamics_v1/analyze_dynamics.py", "dynamics_v1/verify_cell.py", "run_pair_cell.py")]
record = {
    "status": "running", "pair": pair, "lambda": str(lam), "beta": str(beta),
    "seed": seed, "task": task, "job": job, "config": str(CONFIG),
    "config_sha256": CONFIG_SHA256,
    "code_sha256": {str(p.relative_to(ROOT)): sha(p) for p in code_files},
    "started_unix": time.time(), "components": {},
}


def save():
    temp = out / "status.json.tmp"
    temp.write_text(json.dumps(record, indent=2, sort_keys=True))
    temp.replace(out / "status.json")


def call(name, args):
    start = time.time()
    command = [sys.executable, "-u", *args]
    item = {"status": "running", "command": command, "started_unix": start}
    record["components"][name] = item
    save()
    with (out / f"{name}.log").open("w") as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    item.update(status="completed" if result.returncode == 0 else "failed",
                exit_code=result.returncode, elapsed_seconds=time.time() - start)
    save()
    return result.returncode == 0


def marker(block):
    return list((parent / f"block_{block-1:03d}").glob("attempt_*/complete.json"))


save()
parent = out / "parent"
try:
    call("parent", ["c4.py", "--data", "data/CIFAR-100-C", "--output", str(parent),
                    "--gamma", str(lam), "--beta", str(beta), "--seed", str(seed),
                    "--cycles", "1"])
    for block in (5, 15):
        if len(marker(block)) != 1:
            record["components"][f"block{block}_dependent"] = {"status": "unavailable_parent"}
            save()
            continue
        for horizon in (94, 1410):
            name = f"fork_b{block}_h{horizon}"
            dest = out / name
            succeeded = call(name, ["run_measured_fork.py", str(dest), "--parent", str(parent),
                                    "--data", "data/CIFAR-100-C", "--after-block", str(block),
                                    "--horizon", str(horizon), "--output", str(dest)])
            if succeeded:
                call(f"verify_{name}", ["verify_forks.py", str(dest)])
        name = f"dynamics_b{block}"
        dest = out / name
        succeeded = call(name, ["dynamics_v1/run_dynamics.py", "--parent", str(parent),
                                "--output", str(dest), "--block", str(block),
                                "--horizon", "20"])
        if succeeded:
            call(f"analysis_b{block}", ["dynamics_v1/analyze_dynamics.py", str(dest)])
    if len(marker(15)) == 1:
        call("extension", ["dynamics_v1/extend_trajectory.py", "--data", "data/CIFAR-100-C",
                           "--resume-parent", str(parent), "--output", str(out / "extension"),
                           "--gamma", str(lam), "--beta", str(beta), "--seed", str(seed),
                           "--cycles", "3"])
    else:
        record["components"]["extension"] = {"status": "unavailable_parent"}
        save()
    call("verify_manifests", ["dynamics_v1/verify_cell.py", str(out)])
    required = ("parent", "extension", "fork_b5_h94", "fork_b5_h1410",
                "fork_b15_h94", "fork_b15_h1410", "verify_fork_b5_h94",
                "verify_fork_b5_h1410", "verify_fork_b15_h94", "verify_fork_b15_h1410",
                "dynamics_b5", "dynamics_b15", "analysis_b5", "analysis_b15",
                "verify_manifests")
    complete = all(record["components"].get(name, {}).get("status") == "completed"
                   for name in required)
    complete = complete and len(list(parent.glob("block_*/attempt_*/complete.json"))) == 15
    complete = complete and len(list((out / "extension").glob("block_*/attempt_*/complete.json"))) == 30
    record["status"] = "components_completed_coverage_review_required" if complete else "partial_or_failed"
    record["finished_unix"] = time.time()
    save()
    print(json.dumps({"cell": str(out), "status": record["status"]}), flush=True)
except BaseException as exc:
    record["status"] = "supervisor_failed"
    record["error"] = repr(exc)
    record["finished_unix"] = time.time()
    save()
    raise
